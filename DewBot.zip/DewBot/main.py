import discord
from discord.ext import commands
import asyncio
import os
import logging
from bot.config import *
from keep_alive import keep_alive
from bot.models import create_tables
import json

# Setup logging
logging.basicConfig(level=logging.INFO)

# Bot setup with proper intents
intents = discord.Intents.all()
bot = commands.Bot(
    command_prefix='!',
    intents=intents,
    help_command=None,
    case_insensitive=True
)

@bot.event
async def on_ready():
    # Initialize database tables
    try:
        create_tables()
        print('✅ تم إنشاء جداول قاعدة البيانات')
    except Exception as e:
        print(f'❌ خطأ في قاعدة البيانات: {e}')
    
    print(f'✅ البوت {bot.user} متصل بنجاح!')
    print(f'🆔 معرف البوت: {bot.user.id}')
    print(f'🌐 متصل بـ {len(bot.guilds)} سيرفر')

    # Set bot status
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name="𝐛𝐨𝐭 𝐬𝐲𝐬𝐭𝐞𝐦 | !help"
        ),
        status=discord.Status.online
    )

    # Sync slash commands
    try:
        synced = await bot.tree.sync()
        print(f'✅ تم مزامنة {len(synced)} أمر سلاش')
    except Exception as e:
        print(f'❌ خطأ في مزامنة الأوامر: {e}')

@bot.event  
async def on_command(ctx):
    """Check if user can use bot commands before executing"""
    from bot.utils import can_use_bot, create_error_embed

    if not can_use_bot(ctx.author):
        embed = create_error_embed(
            "🚫 ليس لديك صلاحية",
            "البوت مخصص للمشرفين فقط."
        )
        await ctx.send(embed=embed)
        raise commands.CommandError("غير مسموح للعضو باستخدام البوت")

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        embed = discord.Embed(
            title="❌ أمر غير موجود",
            description=f"الأمر `{ctx.message.content.split()[0]}` غير موجود.\nاستخدم `!help` لعرض جميع الأوامر المتاحة.",
            color=0xff0000
        )
        await ctx.send(embed=embed)
    elif isinstance(error, commands.MissingPermissions):
        embed = discord.Embed(
            title="🚫 ليس لديك صلاحية",
            description="ليس لديك الصلاحية المطلوبة لتنفيذ هذا الأمر.",
            color=0xff0000
        )
        await ctx.send(embed=embed)
    elif isinstance(error, commands.MissingRequiredArgument):
        embed = discord.Embed(
            title="⚠️ معامل مطلوب",
            description=f"الأمر `{ctx.command}` يتطلب معاملات إضافية.\nاستخدم `!help {ctx.command}` لمعرفة طريقة الاستخدام.",
            color=0xffaa00
        )
        await ctx.send(embed=embed)
    elif "غير مسموح للعضو باستخدام البوت" in str(error):
        # Already handled in on_command
        pass
    else:
        print(f'خطأ غير متوقع: {error}')

# Load all cogs
async def load_cogs():
    cogs = [
        'bot.cogs.tickets',
        'bot.cogs.applications', 
        'bot.cogs.points',
        'bot.cogs.moderation',
        'bot.cogs.roles',
        'bot.cogs.general'
    ]

    for cog in cogs:
        try:
            await bot.load_extension(cog)
            print(f'✅ تم تحميل {cog}')
        except Exception as e:
            print(f'❌ خطأ في تحميل {cog}: {e}')

async def main():
    async with bot:
        await load_cogs()
        keep_alive()  # تشغيل سيرفر الويب في Thread منفصل
        await bot.start(BOT_TOKEN)

if __name__ == "__main__":
    asyncio.run(main())
