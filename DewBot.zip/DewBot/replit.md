# Overview

This is a comprehensive Discord bot system called "𝐛𝐨𝐭 𝐬𝐲𝐬𝐭𝐞𝐦" built with Python and discord.py. The bot features a modular architecture with various systems including moderation, points management, role management, ticketing, and application processing. The bot is designed to run 24/7 with a keep-alive server and supports both slash commands and prefix commands.

# User Preferences

Preferred communication style: Simple, everyday language.
Bot interface preferences: Arabic interface with comprehensive slash command support and admin control.
Ticket system: Updated panel format with Support/Store/Admin/Kick Mod/Event buttons, no rules in tickets, show member name, supervisors, date, and ticket type.
Application system: Each application type routes to specific log channels with approval/rejection system and DM notifications.
Administrative control: Full control via slash commands for all bot configurations.

# System Architecture

## Backend Architecture
- **Framework**: Python 3.x with discord.py library
- **Web Server**: Flask for keep-alive functionality
- **Database**: PostgreSQL with SQLAlchemy ORM for professional data management
- **Database Adapter**: Compatibility layer maintaining existing API while using PostgreSQL backend
- **Command System**: Hybrid commands supporting both slash (/) and prefix (!) formats
- **Modular Design**: Cog-based architecture for feature separation

## Core Components
- **Main Bot**: Entry point with event handlers and command synchronization
- **Keep-Alive Server**: Flask web server for uptime monitoring
- **Configuration Manager**: Centralized settings and Discord IDs
- **Database Layer**: JSON-based data persistence
- **Utility Functions**: Shared helpers for permissions and embed creation

# Key Components

## Bot Structure
```
main.py - Bot initialization and main event handlers
keep_alive.py - Flask server for uptime monitoring
bot/
├── config.py - Configuration and Discord IDs
├── database.py - JSON-based data storage
├── utils.py - Utility functions and helpers
└── cogs/ - Modular command systems
    ├── applications.py - Staff application system
    ├── general.py - General purpose commands
    ├── moderation.py - Server moderation tools
    ├── points.py - Points management system
    └── roles.py - Role management commands
```

## Command Systems
1. **Moderation System**: Ban, kick, timeout, and other moderation tools
2. **Points System**: Award, remove, and track member points
3. **Role Management**: Create, delete, and assign roles
4. **Applications**: Staff application processing with approval workflows
5. **General Commands**: User info, server stats, and utility commands

## Permission System
- Role-based permissions using Discord role IDs
- Hierarchical access control (admin > staff > kick_mod)
- Permission validation before command execution

# Data Flow

## Command Processing
1. User sends command (slash or prefix)
2. Permission validation using role checking
3. Command execution with error handling
4. Response sent via Discord embeds
5. Data persistence to JSON database if needed

## Application Workflow
1. User submits application via modal
2. Application logged to designated channel
3. Staff review with approval/rejection buttons
4. Automated role assignment upon approval
5. Notification sent to applicant

## Points Management
1. Staff awards/removes points from members
2. Points stored in JSON database
3. Leaderboard generation from stored data
4. Point history tracking for auditing

# External Dependencies

## Core Libraries
- **discord.py**: Discord API wrapper for bot functionality
- **Flask**: Web framework for keep-alive server
- **asyncio**: Asynchronous operation support
- **json**: Data persistence and configuration
- **psutil**: System monitoring for bot stats
- **logging**: Error tracking and debugging

## Discord Integrations
- **Application Commands**: Slash command support
- **Embeds**: Rich message formatting
- **Modals**: Interactive forms for applications
- **Views**: Button interactions for approvals
- **Permissions**: Role-based access control

# Deployment Strategy

## Environment Setup
- Bot token and Discord credentials stored in environment variables
- Fallback configuration in config.py for development
- JSON database file for data persistence

## Keep-Alive System
- Flask web server runs on port 5000
- Health check endpoints for monitoring services
- Threaded execution to maintain bot and web server
- Compatible with UptimeRobot for 24/7 monitoring

## Scalability Considerations
- Modular cog system allows easy feature addition
- JSON database suitable for small to medium servers
- Role-based permissions prevent unauthorized access
- Error handling prevents bot crashes

## Security Features
- Permission validation on all administrative commands
- Role hierarchy enforcement
- Input validation and sanitization
- Audit logging for administrative actions

## Recent Changes (July 28, 2025)

### Phase 1: Core System Updates
- Updated ticket panel to match exact user specifications with "ℹ️ 🎫 نظام التذاكر" format
- Redesigned ticket buttons: 🛠️ Support, 🛒 Store, 🛡️ Admin, 🔨 Kick Mod, 🎉 Event
- Removed rules display from ticket creation, now shows member name, supervisors, date, and ticket type
- Fixed ticket closing functionality - tickets now save to designated logs immediately upon closure
- Added /set-ticket-log slash command for configuring ticket log channels
- Improved application system to route each type to specific log channels
- Enhanced application embeds with better formatting and user avatars
- Added /set-application-log slash command for application log configuration

### Phase 2: Advanced Features Implementation  
- **Ticket Conversation Logs**: Tickets now save full conversation history when closed
- **Staff-Only Bot Access**: Restricted all bot commands to staff members only (admin, staff, store_team, kick_mod)
- **Database-Driven Configuration**: Ticket and application logs now stored in database instead of config files
- **Supervisor Role Management**: Added /set-supervisor command to assign specific roles for ticket types
- **Command Shortcuts System**: Added short aliases for all major commands (e.g., !tp for !ticket-panel)
- **Enhanced Admin Control**: Added granular controls for log channels per ticket/application type
- **Improved Message History**: Ticket logs now include complete conversation transcripts with timestamps
- **Permission System**: Updated permission checking to prevent non-staff access to bot functions
- Updated help system to show all shortcuts and new commands (40 total slash commands)
- Enhanced all embeds with better Arabic formatting and visual improvements

### Phase 3: Database Migration to PostgreSQL (Completed)
- **Complete Database Overhaul**: Migrated entire system from JSON files to PostgreSQL database
- **Professional Schema Design**: Created comprehensive database models (Users, Tickets, Applications, Warnings, Config, ModLogs)
- **Database Adapter Layer**: Built compatibility layer to maintain existing functionality during migration
- **Improved Performance**: PostgreSQL provides better reliability, concurrent access, and data integrity
- **Advanced Features**: Added proper relationships, indexing, and transaction support
- **Scalability Enhancement**: System now supports much larger user bases and concurrent operations
- **Automatic Table Creation**: Database tables are automatically created on bot startup
- **Data Migration**: All existing functionality preserved with improved backend performance

## Future Enhancement Opportunities
- Database migration to SQLite or PostgreSQL for better performance
- Redis integration for caching and session management
- Webhook integration for external service notifications
- Advanced logging and monitoring systems