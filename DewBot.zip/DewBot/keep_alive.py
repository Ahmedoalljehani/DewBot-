from flask import Flask, jsonify
from threading import Thread
import time
import os

app = Flask(__name__)

@app.route('/')
def home():
    return jsonify({
        "status": "online",
        "bot": "𝐛𝐨𝐭 𝐬𝐲𝐬𝐭𝐞𝐦",
        "version": "1.0",
        "message": "البوت يعمل بنجاح!"
    })

@app.route('/health')
def health():
    return jsonify({
        "status": "healthy",
        "timestamp": time.time(),
        "uptime": "running"
    })

@app.route('/ping')
def ping():
    return jsonify({
        "response": "pong",
        "timestamp": time.time()
    })

def run():
    app.run(host='0.0.0.0', port=5000, debug=False)

def keep_alive():
    t = Thread(target=run)
    t.daemon = True
    t.start()
    print("🌐 خادم Keep-Alive يعمل على المنفذ 5000")
    print("🔗 يمكن استخدام UptimeRobot مع هذا الرابط للمراقبة المستمرة")
