import discord
from discord.ext import commands
from discord import app_commands
from bot.config import *
from bot.database_adapter import db
from bot.utils import *
from datetime import timedelta
import asyncio

class TicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label='🛠️ Support', style=discord.ButtonStyle.secondary, custom_id='ticket_support')
    async def support_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.create_ticket(interaction, 'support')
    
    @discord.ui.button(label='🛒 Store', style=discord.ButtonStyle.secondary, custom_id='ticket_store')
    async def store_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.create_ticket(interaction, 'store')
    
    @discord.ui.button(label='🛡️ Admin', style=discord.ButtonStyle.secondary, custom_id='ticket_admin')
    async def admin_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.create_ticket(interaction, 'admin')
    
    @discord.ui.button(label='🔨 Kick Mod', style=discord.ButtonStyle.secondary, custom_id='ticket_kick_mod')
    async def kick_mod_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.create_ticket(interaction, 'kick_mod')
    
    @discord.ui.button(label='🎉 Event', style=discord.ButtonStyle.secondary, custom_id='ticket_event')
    async def event_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.create_ticket(interaction, 'event')
    
    async def create_ticket(self, interaction: discord.Interaction, ticket_type):
        guild = interaction.guild
        user = interaction.user
        
        # Check if user already has an open ticket
        for ticket_id, ticket_data in db.data["tickets"].items():
            if (ticket_data["user_id"] == user.id and 
                ticket_data["guild_id"] == guild.id and 
                ticket_data["status"] == "open"):
                embed = create_error_embed(
                    "❌ تذكرة موجودة",
                    "لديك تذكرة مفتوحة بالفعل. أغلقها أولاً قبل فتح تذكرة جديدة."
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
        
        # Get category
        category = guild.get_channel(TICKET_CATEGORIES[ticket_type])
        if not category:
            embed = create_error_embed(
                "❌ خطأ في التكوين",
                "لم يتم العثور على فئة التذاكر."
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Create ticket 
        ticket_id = db.create_ticket(user.id, guild.id, ticket_type, channel.id)
        
        # Create channel
        channel_name = f"ticket-{ticket_id}-{user.display_name}"
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            user: discord.PermissionOverwrite(read_messages=True, send_messages=True),
            guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True)
        }
        
        # Add role permissions
        role_id = None
        if ticket_type == "support":
            role_id = ROLES["staff"]
        elif ticket_type == "store":
            role_id = ROLES["store_team"]
        elif ticket_type == "admin":
            role_id = ROLES["admin"]
        elif ticket_type == "kick_mod":
            role_id = ROLES["kick_mod"]
        elif ticket_type == "event":
            role_id = ROLES["staff"]
        
        if role_id:
            role = guild.get_role(role_id)
            if role:
                overwrites[role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)
        
        try:
            channel = await category.create_text_channel(
                name=channel_name,
                overwrites=overwrites
            )
            
            # Note: Channel ID is now set when creating the ticket with the new system
            
            # Create ticket embed
            embed = discord.Embed(
                title=f"🎫 تذكرة رقم #{ticket_id}",
                description=f"**👤 العضو:** {user.mention}\n**📝 نوع التذكرة:** {ticket_type.title()}\n**📅 التاريخ:** <t:{int(discord.utils.utcnow().timestamp())}:F>\n**👥 مشرفو التذكرة:** {TICKET_ROLE_MENTIONS.get(ticket_type, '')}",
                color=COLORS["primary"]
            )
            embed.set_thumbnail(url=user.display_avatar.url)
            
            # Mention the appropriate role
            mention = TICKET_ROLE_MENTIONS.get(ticket_type, "")
            
            # Create ticket management view
            view = TicketManagementView(ticket_id)
            
            await channel.send(content=mention, embed=embed, view=view)
            
            # Send DM notification
            dm_embed = create_info_embed(
                "🎫 تم فتح تذكرة جديدة",
                f"تم فتح تذكرة رقم #{ticket_id} من نوع {ticket_type}\nالرابط: {channel.mention}"
            )
            await send_dm(user, dm_embed)
            
            # Response
            success_embed = create_success_embed(
                "✅ تم إنشاء التذكرة",
                f"تم إنشاء تذكرة رقم #{ticket_id} بنجاح!\n{channel.mention}"
            )
            await interaction.response.send_message(embed=success_embed, ephemeral=True)
            
        except Exception as e:
            embed = create_error_embed(
                "❌ خطأ في الإنشاء",
                f"حدث خطأ أثناء إنشاء التذكرة: {str(e)}"
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)

class TicketManagementView(discord.ui.View):
    def __init__(self, ticket_id):
        super().__init__(timeout=None)
        self.ticket_id = ticket_id
    
    @discord.ui.button(label='✅ استلام', style=discord.ButtonStyle.green, custom_id='claim_ticket')
    async def claim_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not has_role_permission(interaction.user, ["staff", "admin", "store_team", "kick_mod"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية للتعامل مع التذاكر."
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        db.claim_ticket(self.ticket_id, interaction.user.id)
        embed = create_success_embed(
            "✅ تم الاستلام",
            f"تم استلام التذكرة من قبل {interaction.user.mention}"
        )
        await interaction.response.send_message(embed=embed)
    
    @discord.ui.button(label='❌ إلغاء الاستلام', style=discord.ButtonStyle.red, custom_id='unclaim_ticket')
    async def unclaim_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not has_role_permission(interaction.user, ["staff", "admin", "store_team", "kick_mod"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية للتعامل مع التذاكر."
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        db.unclaim_ticket(self.ticket_id)
        embed = create_success_embed(
            "✅ تم إلغاء الاستلام",
            f"تم إلغاء استلام التذكرة من قبل {interaction.user.mention}"
        )
        await interaction.response.send_message(embed=embed)
    
    @discord.ui.button(label='➕ إضافة عضو', style=discord.ButtonStyle.secondary, custom_id='add_member')
    async def add_member(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not has_role_permission(interaction.user, ["staff", "admin", "store_team", "kick_mod"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية للتعامل مع التذاكر."
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        modal = AddMemberModal()
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label='📬 تذكير', style=discord.ButtonStyle.secondary, custom_id='remind_user')
    async def remind_user(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not has_role_permission(interaction.user, ["staff", "admin", "store_team", "kick_mod"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية للتعامل مع التذاكر."
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        ticket = db.get_ticket(self.ticket_id)
        if ticket:
            user = interaction.guild.get_member(ticket.user_id)
            if user:
                dm_embed = create_info_embed(
                    "📬 تذكير بالتذكرة",
                    f"تذكير: لديك تذكرة مفتوحة #{self.ticket_id}\nيرجى التفاعل معها أو إغلاقها إذا لم تعد بحاجة إليها."
                )
                sent = await send_dm(user, dm_embed)
                if sent:
                    embed = create_success_embed(
                        "✅ تم الإرسال",
                        f"تم إرسال تذكير لـ {user.mention}"
                    )
                else:
                    embed = create_error_embed(
                        "❌ فشل الإرسال",
                        "لم يتم إرسال التذكير (الرسائل الخاصة مغلقة)"
                    )
                await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @discord.ui.button(label='🔒 إغلاق', style=discord.ButtonStyle.red, custom_id='close_ticket')
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not has_role_permission(interaction.user, ["staff", "admin", "store_team", "kick_mod"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية للتعامل مع التذاكر."
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        view = ConfirmView()
        embed = create_warning_embed(
            "⚠️ تأكيد الإغلاق",
            "هل أنت متأكد من إغلاق هذه التذكرة؟"
        )
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        
        await view.wait()
        if view.value:
            await self.close_ticket_process(interaction)
    
    async def close_ticket_process(self, interaction):
        from bot.utils import get_channel_history
        from datetime import timedelta
        
        ticket = db.get_ticket(self.ticket_id)
        if not ticket:
            return
        
        # Close in database
        db.close_ticket(self.ticket_id)
        
        # Get log channel (try database first, then config)
        log_channel_id = db.get_ticket_log(interaction.guild.id, ticket.ticket_type) or TICKET_LOGS.get(ticket.ticket_type)
        if log_channel_id:
            log_channel = interaction.guild.get_channel(log_channel_id)
            if log_channel:
                # Get conversation history
                conversation = await get_channel_history(interaction.channel, limit=100)
                
                # Create transcript embed
                user = interaction.guild.get_member(ticket.user_id)
                embed = discord.Embed(
                    title=f"📋 سجل تذكرة #{self.ticket_id}",
                    description=f"**النوع:** {ticket.ticket_type}\n**العضو:** {user.mention if user else 'غير معروف'}\n**تم الإغلاق بواسطة:** {interaction.user.mention}\n**تاريخ الإنشاء:** <t:{int(ticket.created_at.timestamp())}:F>\n**تاريخ الإغلاق:** <t:{int(discord.utils.utcnow().timestamp())}:F>",
                    color=COLORS["info"]
                )
                
                # Add conversation history
                if conversation and len(conversation) > 0:
                    # Split conversation into chunks if too long
                    if len(conversation) > 1900:
                        conversation = conversation[:1900] + "\n... (تم اقتطاع الرسائل)"
                    embed.add_field(
                        name="💬 سجل المحادثة",
                        value=f"```{conversation}```" if conversation else "لا توجد رسائل",
                        inline=False
                    )
                
                await log_channel.send(embed=embed)
        
        # Send DM to user
        if ticket["user_id"]:
            user = interaction.guild.get_member(ticket["user_id"])
            if user:
                dm_embed = create_info_embed(
                    "🔒 تم إغلاق التذكرة",
                    f"تم إغلاق تذكرة #{self.ticket_id} بواسطة الفريق.\nشكراً لتواصلك معنا!"
                )
                await send_dm(user, dm_embed)
        
        # Delete channel after delay
        await interaction.channel.send("سيتم حذف القناة خلال 5 ثوانٍ...")
        await asyncio.sleep(5)
        await interaction.channel.delete()

class AddMemberModal(discord.ui.Modal, title='إضافة عضو للتذكرة'):
    def __init__(self):
        super().__init__()
    
    member = discord.ui.TextInput(
        label='معرف العضو أو المنشن',
        placeholder='123456789 أو @username',
        required=True
    )
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            # Parse member
            member_input = self.member.value.strip()
            if member_input.startswith('<@') and member_input.endswith('>'):
                member_id = int(member_input[2:-1].replace('!', ''))
            else:
                member_id = int(member_input)
            
            member = interaction.guild.get_member(member_id)
            if not member:
                embed = create_error_embed(
                    "❌ عضو غير موجود",
                    "لم يتم العثور على العضو المحدد."
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Add permissions
            overwrites = interaction.channel.overwrites
            overwrites[member] = discord.PermissionOverwrite(read_messages=True, send_messages=True)
            await interaction.channel.edit(overwrites=overwrites)
            
            embed = create_success_embed(
                "✅ تم إضافة العضو",
                f"تم إضافة {member.mention} للتذكرة بنجاح."
            )
            await interaction.response.send_message(embed=embed)
            
        except ValueError:
            embed = create_error_embed(
                "❌ معرف خاطئ",
                "يرجى إدخال معرف صحيح للعضو."
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = create_error_embed(
                "❌ خطأ",
                f"حدث خطأ: {str(e)}"
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)

class Tickets(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="ticket-panel", description="إنشاء بانل التذاكر")
    @app_commands.describe()
    async def ticket_panel(self, ctx):
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لإنشاء بانل التذاكر."
            )
            await ctx.send(embed=embed)
            return
        
        embed = discord.Embed(
            title="ℹ️ 🎫 نظام التذاكر",
            description="اختر نوع التذكرة المناسب من الأزرار أدناه:\n\n🛠️ **Support** - للدعم التقني والمساعدة العامة\n🛒 **Store** - لمسائل المتجر والمشتريات\n🛡️ **Admin** - للتواصل مع الإدارة العليا\n🔨 **Kick Mod** - لطلبات الإشراف والمودريشن\n🎉 **Event** - لتنظيم الفعاليات والأنشطة",
            color=COLORS["primary"]
        )
        
        view = TicketView()
        await ctx.send(embed=embed, view=view)
    
    @commands.hybrid_command(name="rename-ticket", description="إعادة تسمية التذكرة")
    @app_commands.describe(new_name="الاسم الجديد للتذكرة")
    async def rename_ticket(self, ctx, *, new_name: str):
        if not has_role_permission(ctx.author, ["admin", "staff"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لإعادة تسمية التذاكر."
            )
            await ctx.send(embed=embed)
            return
        
        # Check if in ticket channel
        channel_name = ctx.channel.name
        if not channel_name.startswith("ticket-"):
            embed = create_error_embed(
                "❌ ليس قناة تذكرة",
                "هذا الأمر يعمل فقط في قنوات التذاكر."
            )
            await ctx.send(embed=embed)
            return
        
        try:
            await ctx.channel.edit(name=new_name)
            embed = create_success_embed(
                "✅ تم تغيير الاسم",
                f"تم تغيير اسم التذكرة إلى: {new_name}"
            )
            await ctx.send(embed=embed)
        except Exception as e:
            embed = create_error_embed(
                "❌ خطأ",
                f"حدث خطأ أثناء تغيير الاسم: {str(e)}"
            )
            await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="set-opening-message", description="تعيين رسالة فتح التذكرة")
    @app_commands.describe(message="نص الرسالة")
    async def set_opening_message(self, ctx, *, message: str):
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لتعديل رسائل التذاكر."
            )
            await ctx.send(embed=embed)
            return
        
        # This would be implemented with additional database fields
        embed = create_success_embed(
            "✅ تم حفظ الرسالة",
            "تم حفظ رسالة فتح التذكرة الجديدة."
        )
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="set-ticket-log", description="تعيين قناة لوق التذاكر")
    @app_commands.describe(ticket_type="نوع التذكرة", channel="القناة")
    async def set_ticket_log(self, ctx, ticket_type: str, channel: discord.TextChannel):
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لتعديل إعدادات التذاكر."
            )
            await ctx.send(embed=embed)
            return
        
        valid_types = ["support", "store", "admin", "kick_mod", "event"]
        if ticket_type not in valid_types:
            embed = create_error_embed(
                "❌ نوع خاطئ",
                f"الأنواع المتاحة: {', '.join(valid_types)}"
            )
            await ctx.send(embed=embed)
            return
        
        # Save to database
        db.set_ticket_log(ctx.guild.id, ticket_type, channel.id)
        
        embed = create_success_embed(
            "✅ تم التحديث",
            f"تم تعيين {channel.mention} كقناة لوق لتذاكر {ticket_type}"
        )
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="set-supervisor", description="تعيين الرتبة المشرفة للتذاكر")
    @app_commands.describe(ticket_type="نوع التذكرة", role="الرتبة المشرفة")
    async def set_supervisor(self, ctx, ticket_type: str, role: discord.Role):
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لتعديل إعدادات التذاكر."
            )
            await ctx.send(embed=embed)
            return
        
        valid_types = ["support", "store", "admin", "kick_mod", "event"]
        if ticket_type not in valid_types:
            embed = create_error_embed(
                "❌ نوع خاطئ",
                f"الأنواع المتاحة: {', '.join(valid_types)}"
            )
            await ctx.send(embed=embed)
            return
        
        db.set_supervisor_role(ctx.guild.id, ticket_type, role.id)
        
        embed = create_success_embed(
            "✅ تم التحديث",
            f"تم تعيين {role.mention} كرتبة مشرفة للتذاكر من نوع {ticket_type}"
        )
        await ctx.send(embed=embed)

    # Command aliases (shortcuts)
    @commands.command(name="tp", hidden=True)
    async def ticket_panel_alias(self, ctx):
        await self.ticket_panel(ctx)
    
    @commands.command(name="rt", hidden=True) 
    async def rename_ticket_alias(self, ctx, *, new_name: str):
        await self.rename_ticket(ctx, new_name=new_name)
    
    @commands.command(name="som", hidden=True)
    async def set_opening_message_alias(self, ctx, *, message: str):
        await self.set_opening_message(ctx, message=message)
    
    @commands.command(name="stl", hidden=True)
    async def set_ticket_log_alias(self, ctx, ticket_type: str, channel: discord.TextChannel):
        await self.set_ticket_log(ctx, ticket_type, channel)
    
    @commands.command(name="ss", hidden=True)
    async def set_supervisor_alias(self, ctx, ticket_type: str, role: discord.Role):
        await self.set_supervisor(ctx, ticket_type, role)

async def setup(bot):
    await bot.add_cog(Tickets(bot))
