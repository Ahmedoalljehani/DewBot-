import discord
from discord.ext import commands
from discord import app_commands
from bot.config import *
from bot.utils import *

class Roles(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="createrole", description="إنشاء رتبة جديدة")
    @app_commands.describe(name="اسم الرتبة")
    async def createrole(self, ctx, *, name: str):
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لإنشاء الرتب."
            )
            await ctx.send(embed=embed)
            return
        
        try:
            role = await ctx.guild.create_role(name=name, reason=f"تم الإنشاء بواسطة {ctx.author}")
            
            embed = create_success_embed(
                "✅ تم إنشاء الرتبة",
                f"**الرتبة:** {role.mention}\n**الاسم:** {name}\n**المعرف:** {role.id}\n**بواسطة:** {ctx.author.mention}"
            )
            await ctx.send(embed=embed)
            
        except discord.Forbidden:
            embed = create_error_embed(
                "❌ فشل الإنشاء",
                "ليس لدي الصلاحية لإنشاء الرتب."
            )
            await ctx.send(embed=embed)
        except Exception as e:
            embed = create_error_embed(
                "❌ خطأ",
                f"حدث خطأ أثناء إنشاء الرتبة: {str(e)}"
            )
            await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="deleterole", description="حذف رتبة")
    @app_commands.describe(role="الرتبة المراد حذفها")
    async def deleterole(self, ctx, role: discord.Role):
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لحذف الرتب."
            )
            await ctx.send(embed=embed)
            return
        
        # Check if role is protected
        protected_roles = list(ROLES.values())
        if role.id in protected_roles:
            embed = create_error_embed(
                "❌ رتبة محمية",
                "لا يمكن حذف هذه الرتبة لأنها مهمة للنظام."
            )
            await ctx.send(embed=embed)
            return
        
        if role >= ctx.author.top_role:
            embed = create_error_embed(
                "❌ رتبة أعلى",
                "لا يمكنك حذف رتبة أعلى من رتبتك أو مساوية لها."
            )
            await ctx.send(embed=embed)
            return
        
        try:
            role_name = role.name
            await role.delete(reason=f"تم الحذف بواسطة {ctx.author}")
            
            embed = create_success_embed(
                "✅ تم حذف الرتبة",
                f"**الرتبة:** {role_name}\n**بواسطة:** {ctx.author.mention}"
            )
            await ctx.send(embed=embed)
            
        except discord.Forbidden:
            embed = create_error_embed(
                "❌ فشل الحذف",
                "ليس لدي الصلاحية لحذف هذه الرتبة."
            )
            await ctx.send(embed=embed)
        except Exception as e:
            embed = create_error_embed(
                "❌ خطأ",
                f"حدث خطأ أثناء حذف الرتبة: {str(e)}"
            )
            await ctx.send(embed=embed)
    
    @commands.command(name="r+")
    async def give_role(self, ctx, role: discord.Role, user: discord.Member):
        """إعطاء رتبة - استخدام: !r+ @role @user"""
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لإعطاء الرتب."
            )
            await ctx.send(embed=embed)
            return
        
        if role >= ctx.author.top_role:
            embed = create_error_embed(
                "❌ رتبة أعلى",
                "لا يمكنك إعطاء رتبة أعلى من رتبتك أو مساوية لها."
            )
            await ctx.send(embed=embed)
            return
        
        if role in user.roles:
            embed = create_warning_embed(
                "⚠️ رتبة موجودة",
                f"{user.mention} يملك الرتبة {role.mention} بالفعل."
            )
            await ctx.send(embed=embed)
            return
        
        try:
            await user.add_roles(role, reason=f"تم الإعطاء بواسطة {ctx.author}")
            
            embed = create_success_embed(
                "✅ تم إعطاء الرتبة",
                f"**العضو:** {user.mention}\n**الرتبة:** {role.mention}\n**بواسطة:** {ctx.author.mention}"
            )
            await ctx.send(embed=embed)
            
            # Send DM to user
            dm_embed = create_success_embed(
                "🎉 تم منحك رتبة جديدة",
                f"**السيرفر:** {ctx.guild.name}\n**الرتبة:** {role.name}\n**بواسطة:** {ctx.author.mention}"
            )
            await send_dm(user, dm_embed)
            
        except discord.Forbidden:
            embed = create_error_embed(
                "❌ فشل الإعطاء",
                "ليس لدي الصلاحية لإعطاء هذه الرتبة."
            )
            await ctx.send(embed=embed)
        except Exception as e:
            embed = create_error_embed(
                "❌ خطأ",
                f"حدث خطأ أثناء إعطاء الرتبة: {str(e)}"
            )
            await ctx.send(embed=embed)
    
    @commands.command(name="r-")
    async def remove_role(self, ctx, role: discord.Role, user: discord.Member):
        """إزالة رتبة - استخدام: !r- @role @user"""
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لإزالة الرتب."
            )
            await ctx.send(embed=embed)
            return
        
        if role >= ctx.author.top_role:
            embed = create_error_embed(
                "❌ رتبة أعلى",
                "لا يمكنك إزالة رتبة أعلى من رتبتك أو مساوية لها."
            )
            await ctx.send(embed=embed)
            return
        
        if role not in user.roles:
            embed = create_warning_embed(
                "⚠️ رتبة غير موجودة",
                f"{user.mention} لا يملك الرتبة {role.mention}."
            )
            await ctx.send(embed=embed)
            return
        
        try:
            await user.remove_roles(role, reason=f"تم الإزالة بواسطة {ctx.author}")
            
            embed = create_success_embed(
                "✅ تم إزالة الرتبة",
                f"**العضو:** {user.mention}\n**الرتبة:** {role.mention}\n**بواسطة:** {ctx.author.mention}"
            )
            await ctx.send(embed=embed)
            
            # Send DM to user
            dm_embed = create_warning_embed(
                "📉 تم إزالة رتبة",
                f"**السيرفر:** {ctx.guild.name}\n**الرتبة:** {role.name}\n**بواسطة:** {ctx.author.mention}"
            )
            await send_dm(user, dm_embed)
            
        except discord.Forbidden:
            embed = create_error_embed(
                "❌ فشل الإزالة",
                "ليس لدي الصلاحية لإزالة هذه الرتبة."
            )
            await ctx.send(embed=embed)
        except Exception as e:
            embed = create_error_embed(
                "❌ خطأ",
                f"حدث خطأ أثناء إزالة الرتبة: {str(e)}"
            )
            await ctx.send(embed=embed)

    # Command shortcuts
    @commands.command(name="cr", hidden=True)
    async def createrole_alias(self, ctx, *, role_name: str):
        await self.createrole(ctx, role_name=role_name)
    
    @commands.command(name="dr", hidden=True)
    async def deleterole_alias(self, ctx, *, role_name: str):
        await self.deleterole(ctx, role_name=role_name)

async def setup(bot):
    await bot.add_cog(Roles(bot))
