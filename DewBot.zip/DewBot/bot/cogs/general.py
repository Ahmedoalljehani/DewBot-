import discord
from discord.ext import commands
from discord import app_commands
from bot.config import *
from bot.database import db
from bot.utils import *
import time
import psutil
import os

class General(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="userinfo", description="معلومات عضو")
    @app_commands.describe(user="العضو المراد عرض معلوماته")
    async def userinfo(self, ctx, user: discord.Member = None):
        if user is None:
            user = ctx.author
        
        embed = discord.Embed(
            title="👤 معلومات العضو",
            color=COLORS["info"]
        )
        embed.set_thumbnail(url=user.display_avatar.url)
        
        # Basic info
        embed.add_field(
            name="📛 الاسم",
            value=f"{user.display_name}\n({user.name})",
            inline=True
        )
        embed.add_field(
            name="🆔 المعرف",
            value=user.id,
            inline=True
        )
        embed.add_field(
            name="🤖 بوت",
            value="نعم" if user.bot else "لا",
            inline=True
        )
        
        # Dates
        embed.add_field(
            name="📅 تاريخ الإنشاء",
            value=f"<t:{int(user.created_at.timestamp())}:F>",
            inline=True
        )
        embed.add_field(
            name="📥 تاريخ الانضمام",
            value=f"<t:{int(user.joined_at.timestamp())}:F>",
            inline=True
        )
        
        # Roles
        roles = [role.mention for role in user.roles[1:]]  # Skip @everyone
        if roles:
            embed.add_field(
                name=f"👑 الرتب ({len(roles)})",
                value=" ".join(roles[:10]) + ("..." if len(roles) > 10 else ""),
                inline=False
            )
        
        # Points
        points = db.get_points(user.id)
        if points > 0:
            embed.add_field(
                name="💎 النقاط",
                value=f"{points:,} نقطة",
                inline=True
            )
        
        # Warnings
        warnings = db.get_warnings(user.id, ctx.guild.id)
        if warnings:
            embed.add_field(
                name="⚠️ التحذيرات",
                value=f"{len(warnings)} تحذير",
                inline=True
            )
        
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="serverinfo", description="معلومات السيرفر")
    async def serverinfo(self, ctx):
        guild = ctx.guild
        
        embed = discord.Embed(
            title="🏰 معلومات السيرفر",
            color=COLORS["info"]
        )
        
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        
        # Basic info
        embed.add_field(
            name="📛 الاسم",
            value=guild.name,
            inline=True
        )
        embed.add_field(
            name="🆔 المعرف",
            value=guild.id,
            inline=True
        )
        embed.add_field(
            name="👑 المالك",
            value=guild.owner.mention if guild.owner else "غير معروف",
            inline=True
        )
        
        # Dates
        embed.add_field(
            name="📅 تاريخ الإنشاء",
            value=f"<t:{int(guild.created_at.timestamp())}:F>",
            inline=True
        )
        
        # Stats
        embed.add_field(
            name="👥 الأعضاء",
            value=f"{guild.member_count:,}",
            inline=True
        )
        embed.add_field(
            name="👑 الرتب",
            value=f"{len(guild.roles):,}",
            inline=True
        )
        embed.add_field(
            name="💬 القنوات",
            value=f"نصية: {len(guild.text_channels)}\nصوتية: {len(guild.voice_channels)}",
            inline=True
        )
        embed.add_field(
            name="😀 الإيموجي",
            value=f"{len(guild.emojis):,}",
            inline=True
        )
        embed.add_field(
            name="🔒 مستوى التحقق",
            value=guild.verification_level.name,
            inline=True
        )
        
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="roleinfo", description="معلومات رتبة")
    @app_commands.describe(role="الرتبة المراد عرض معلوماتها")
    async def roleinfo(self, ctx, role: discord.Role):
        embed = discord.Embed(
            title="👑 معلومات الرتبة",
            color=role.color if role.color != discord.Color.default() else COLORS["info"]
        )
        
        embed.add_field(
            name="📛 الاسم",
            value=role.name,
            inline=True
        )
        embed.add_field(
            name="🆔 المعرف",
            value=role.id,
            inline=True
        )
        embed.add_field(
            name="🎨 اللون",
            value=str(role.color),
            inline=True
        )
        embed.add_field(
            name="📅 تاريخ الإنشاء",
            value=f"<t:{int(role.created_at.timestamp())}:F>",
            inline=True
        )
        embed.add_field(
            name="👥 عدد الأعضاء",
            value=f"{len(role.members):,}",
            inline=True
        )
        embed.add_field(
            name="📊 الموضع",
            value=f"{role.position}/{len(ctx.guild.roles)}",
            inline=True
        )
        embed.add_field(
            name="🔗 قابل للمنشن",
            value="نعم" if role.mentionable else "لا",
            inline=True
        )
        embed.add_field(
            name="👁️ ظاهر منفصل",
            value="نعم" if role.hoist else "لا",
            inline=True
        )
        embed.add_field(
            name="🤖 مدار بواسطة بوت",
            value="نعم" if role.managed else "لا",
            inline=True
        )
        
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="membercount", description="عدد الأعضاء")
    async def membercount(self, ctx):
        guild = ctx.guild
        
        total = guild.member_count
        humans = len([m for m in guild.members if not m.bot])
        bots = len([m for m in guild.members if m.bot])
        online = len([m for m in guild.members if m.status != discord.Status.offline])
        
        embed = discord.Embed(
            title="👥 إحصائيات الأعضاء",
            color=COLORS["info"]
        )
        
        embed.add_field(
            name="📊 إجمالي الأعضاء",
            value=f"{total:,}",
            inline=True
        )
        embed.add_field(
            name="👤 البشر",
            value=f"{humans:,}",
            inline=True
        )
        embed.add_field(
            name="🤖 البوتات",
            value=f"{bots:,}",
            inline=True
        )
        embed.add_field(
            name="🟢 متصل",
            value=f"{online:,}",
            inline=True
        )
        embed.add_field(
            name="⚫ غير متصل",
            value=f"{total - online:,}",
            inline=True
        )
        
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="modlogs", description="سجل مخالفات عضو")
    @app_commands.describe(user="العضو المراد عرض سجله")
    async def modlogs(self, ctx, user: discord.Member):
        warnings = db.get_warnings(user.id, ctx.guild.id)
        
        embed = discord.Embed(
            title="📋 سجل المخالفات",
            description=f"**العضو:** {user.mention}",
            color=COLORS["warning"] if warnings else COLORS["success"]
        )
        
        embed.add_field(
            name="⚠️ التحذيرات",
            value=f"{len(warnings)} تحذير",
            inline=True
        )
        
        # Show recent warnings
        if warnings:
            recent_warnings = warnings[-3:]  # Last 3 warnings
            warning_text = ""
            for warning in recent_warnings:
                moderator = ctx.guild.get_member(warning["moderator_id"])
                moderator_name = moderator.mention if moderator else "غير معروف"
                warning_text += f"**#{warning['id']}** - {warning['reason'][:50]}{'...' if len(warning['reason']) > 50 else ''}\n"
            
            embed.add_field(
                name="📝 آخر التحذيرات",
                value=warning_text,
                inline=False
            )
        
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="ping", description="فحص سرعة الاستجابة")
    async def ping(self, ctx):
        start_time = time.time()
        
        embed = discord.Embed(
            title="🏓 جاري فحص البنق...",
            color=COLORS["info"]
        )
        message = await ctx.send(embed=embed)
        
        end_time = time.time()
        
        api_ping = round(self.bot.latency * 1000)
        bot_ping = round((end_time - start_time) * 1000)
        
        # Determine ping status
        if api_ping < 100:
            status = "🟢 ممتاز"
            color = COLORS["success"]
        elif api_ping < 200:
            status = "🟡 جيد"
            color = COLORS["warning"]
        else:
            status = "🔴 بطيء"
            color = COLORS["error"]
        
        embed = discord.Embed(
            title="🏓 نتائج البنق",
            color=color
        )
        embed.add_field(
            name="📡 بنق API",
            value=f"{api_ping}ms",
            inline=True
        )
        embed.add_field(
            name="🤖 بنق البوت",
            value=f"{bot_ping}ms",
            inline=True
        )
        embed.add_field(
            name="📊 الحالة",
            value=status,
            inline=True
        )
        
        await message.edit(embed=embed)
    
    @commands.hybrid_command(name="stats", description="إحصائيات البوت")
    async def stats(self, ctx):
        # System stats
        process = psutil.Process(os.getpid())
        memory_usage = process.memory_info().rss / 1024 / 1024  # MB
        cpu_usage = process.cpu_percent()
        
        # Bot stats
        total_guilds = len(self.bot.guilds)
        total_users = len(self.bot.users)
        total_commands = len(self.bot.commands)
        
        embed = discord.Embed(
            title="📊 إحصائيات البوت",
            color=COLORS["primary"]
        )
        
        embed.add_field(
            name="🏰 السيرفرات",
            value=f"{total_guilds:,}",
            inline=True
        )
        embed.add_field(
            name="👥 المستخدمين",
            value=f"{total_users:,}",
            inline=True
        )
        embed.add_field(
            name="⚙️ الأوامر",
            value=f"{total_commands:,}",
            inline=True
        )
        embed.add_field(
            name="🧠 استخدام الذاكرة",
            value=f"{memory_usage:.1f} MB",
            inline=True
        )
        embed.add_field(
            name="⚡ استخدام المعالج",
            value=f"{cpu_usage:.1f}%",
            inline=True
        )
        embed.add_field(
            name="🏓 البنق",
            value=f"{round(self.bot.latency * 1000)}ms",
            inline=True
        )
        
        # Uptime
        uptime = discord.utils.utcnow() - self.bot.start_time if hasattr(self.bot, 'start_time') else None
        if uptime:
            embed.add_field(
                name="⏰ وقت التشغيل",
                value=f"{uptime.days} يوم، {uptime.seconds // 3600} ساعة",
                inline=True
            )
        
        embed.set_footer(text=f"𝐛𝐨𝐭 𝐬𝐲𝐬𝐭𝐞𝐦 • Discord.py {discord.__version__}")
        
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="avatar", description="صورة عضو")
    @app_commands.describe(user="العضو المراد عرض صورته")
    async def avatar(self, ctx, user: discord.Member = None):
        if user is None:
            user = ctx.author
        
        embed = discord.Embed(
            title=f"🖼️ صورة {user.display_name}",
            color=COLORS["info"]
        )
        embed.set_image(url=user.display_avatar.url)
        embed.add_field(
            name="🔗 رابط الصورة",
            value=f"[اضغط هنا]({user.display_avatar.url})",
            inline=False
        )
        
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="help", description="قائمة الأوامر")
    async def help(self, ctx):
        embed = discord.Embed(
            title="📋 قائمة أوامر البوت",
            description="جميع الأوامر متاحة بصيغة `/أمر` أو `!أمر`",
            color=COLORS["primary"]
        )
        
        # Tickets
        embed.add_field(
            name="🎫 نظام التذاكر",
            value="```/ticket-panel | !ticket-panel | !tp\n/rename-ticket | !rename-ticket | !rt\n/set-opening-message | !set-opening-message | !som\n/set-ticket-log | !set-ticket-log | !stl\n/set-supervisor | !set-supervisor | !ss```",
            inline=False
        )
        
        # Applications
        embed.add_field(
            name="📝 نظام التقديمات",
            value="```/apply-panel | !apply-panel | !ap\n/apply-staff | !apply-staff | !as\n/apply-mod | !apply-mod | !am\n/apply-event | !apply-event | !ae\n/set-application-log | !set-application-log | !sal```",
            inline=False
        )
        
        # Points
        embed.add_field(
            name="💎 نظام النقاط",
            value="```/point | !point | !p\n/points-add | !n @user +5\n/points-remove | !n @user -3\n/points-set | !n @user 10\n/points-delete | !re @user\n/points-list | !points-list | !pl```",
            inline=False
        )
        
        # Moderation
        embed.add_field(
            name="🛡️ نظام الإشراف",
            value="```/ban | !ban | !b\n/kick | !kick | !k\n/mute | !timeout | !m\n/unmute | !untimeout | !um\n/warn | !warn | !w\n/infractions | !warnings | !inf\n/unwarn | !unwarn | !uw\n/clear | !clear | !c\n/lock | !lock | !l\n/unlock | !unlock | !ul\n/say | !say | !s\n/rules | !rules | !r```",
            inline=False
        )
        
        # Roles
        embed.add_field(
            name="👑 إدارة الرتب",
            value="```/createrole | !createrole | !cr\n/deleterole | !deleterole | !dr\n!r+ @role @user\n!r- @role @user```",
            inline=False
        )
        
        # General
        embed.add_field(
            name="ℹ️ الأوامر العامة",
            value="```/userinfo | !userinfo\n/serverinfo | !serverinfo\n/roleinfo | !roleinfo\n/membercount | !membercount\n/modlogs | !modlogs\n/ping | !ping\n/stats | !stats\n/avatar | !avatar\n/help | !help\n/about | !about```",
            inline=False
        )
        
        embed.set_footer(text="𝐛𝐨𝐭 𝐬𝐲𝐬𝐭𝐞𝐦 | للمساعدة، تواصل مع الإدارة")
        
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="about", description="معلومات عن البوت")
    async def about(self, ctx):
        embed = discord.Embed(
            title="🤖 معلومات البوت",
            description="**𝐛𝐨𝐭 𝐬𝐲𝐬𝐭𝐞𝐦** - نظام إدارة شامل للديسكورد",
            color=COLORS["primary"]
        )
        
        embed.add_field(
            name="📋 الميزات",
            value="• نظام التذاكر المتطور\n• نظام التقديمات\n• إدارة النقاط\n• أدوات الإشراف\n• إدارة الرتب\n• والمزيد...",
            inline=False
        )
        
        embed.add_field(
            name="⚙️ التقنيات",
            value="• Discord.py\n• Python 3.11+\n• قاعدة بيانات JSON\n• Uptime Robot",
            inline=True
        )
        
        embed.add_field(
            name="📊 الإحصائيات",
            value=f"• {len(self.bot.guilds)} سيرفر\n• {len(self.bot.users)} مستخدم\n• {len(self.bot.commands)} أمر",
            inline=True
        )
        
        embed.add_field(
            name="🔗 الروابط",
            value="[دعوة البوت](https://discord.com/api/oauth2/authorize?client_id=1395791277219385435&permissions=8&scope=bot%20applications.commands)",
            inline=False
        )
        
        embed.set_footer(text=f"تم التطوير خصيصاً • الإصدار 1.0")
        
        if ctx.guild and ctx.guild.icon:
            embed.set_thumbnail(url=ctx.guild.icon.url)
        
        await ctx.send(embed=embed)

async def setup(bot):
    # Store start time for uptime calculation
    bot.start_time = discord.utils.utcnow()
    await bot.add_cog(General(bot))
