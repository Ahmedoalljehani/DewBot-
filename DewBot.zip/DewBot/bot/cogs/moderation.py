import discord
from discord.ext import commands
from discord import app_commands
from bot.config import *
from bot.database_adapter import db
from bot.utils import *
import asyncio
from datetime import datetime, timedelta

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="ban", description="حظر عضو")
    @app_commands.describe(user="العضو المراد حظره", reason="سبب الحظر")
    async def ban(self, ctx, user: discord.Member, *, reason: str = "لم يتم تحديد سبب"):
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لحظر الأعضاء."
            )
            await ctx.send(embed=embed)
            return
        
        if user == ctx.author:
            embed = create_error_embed(
                "❌ خطأ",
                "لا يمكنك حظر نفسك."
            )
            await ctx.send(embed=embed)
            return
        
        if user == ctx.guild.owner:
            embed = create_error_embed(
                "❌ خطأ",
                "لا يمكن حظر مالك السيرفر."
            )
            await ctx.send(embed=embed)
            return
        
        try:
            # Send DM before ban
            dm_embed = create_error_embed(
                "🔨 تم حظرك",
                f"**السيرفر:** {ctx.guild.name}\n**السبب:** {reason}\n**بواسطة:** {ctx.author.mention}"
            )
            await send_dm(user, dm_embed)
            
            # Ban the user
            await user.ban(reason=f"بواسطة: {ctx.author} | السبب: {reason}")
            
            embed = create_success_embed(
                "✅ تم الحظر",
                f"**العضو:** {user.mention}\n**السبب:** {reason}\n**بواسطة:** {ctx.author.mention}"
            )
            await ctx.send(embed=embed)
            
        except discord.Forbidden:
            embed = create_error_embed(
                "❌ فشل الحظر",
                "ليس لدي الصلاحية لحظر هذا العضو."
            )
            await ctx.send(embed=embed)
        except Exception as e:
            embed = create_error_embed(
                "❌ خطأ",
                f"حدث خطأ أثناء الحظر: {str(e)}"
            )
            await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="kick", description="طرد عضو")
    @app_commands.describe(user="العضو المراد طرده", reason="سبب الطرد")
    async def kick(self, ctx, user: discord.Member, *, reason: str = "لم يتم تحديد سبب"):
        if not has_role_permission(ctx.author, ["admin", "kick_mod"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لطرد الأعضاء."
            )
            await ctx.send(embed=embed)
            return
        
        if user == ctx.author:
            embed = create_error_embed(
                "❌ خطأ",
                "لا يمكنك طرد نفسك."
            )
            await ctx.send(embed=embed)
            return
        
        try:
            # Send DM before kick
            dm_embed = create_warning_embed(
                "👢 تم طردك",
                f"**السيرفر:** {ctx.guild.name}\n**السبب:** {reason}\n**بواسطة:** {ctx.author.mention}"
            )
            await send_dm(user, dm_embed)
            
            # Kick the user
            await user.kick(reason=f"بواسطة: {ctx.author} | السبب: {reason}")
            
            embed = create_success_embed(
                "✅ تم الطرد",
                f"**العضو:** {user.mention}\n**السبب:** {reason}\n**بواسطة:** {ctx.author.mention}"
            )
            await ctx.send(embed=embed)
            
        except discord.Forbidden:
            embed = create_error_embed(
                "❌ فشل الطرد",
                "ليس لدي الصلاحية لطرد هذا العضو."
            )
            await ctx.send(embed=embed)
        except Exception as e:
            embed = create_error_embed(
                "❌ خطأ",
                f"حدث خطأ أثناء الطرد: {str(e)}"
            )
            await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="mute", description="كتم عضو")
    @app_commands.describe(user="العضو المراد كتمه", duration="مدة الكتم بالدقائق", reason="سبب الكتم")
    async def mute(self, ctx, user: discord.Member, duration: int = 10, *, reason: str = "لم يتم تحديد سبب"):
        if not has_role_permission(ctx.author, ["admin", "kick_mod"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لكتم الأعضاء."
            )
            await ctx.send(embed=embed)
            return
        
        if user == ctx.author:
            embed = create_error_embed(
                "❌ خطأ",
                "لا يمكنك كتم نفسك."
            )
            await ctx.send(embed=embed)
            return
        
        try:
            # Calculate timeout duration
            timeout_until = discord.utils.utcnow() + timedelta(minutes=duration)
            
            # Apply timeout
            await user.timeout(timeout_until, reason=f"بواسطة: {ctx.author} | السبب: {reason}")
            
            # Send DM
            dm_embed = create_warning_embed(
                "🔇 تم كتمك",
                f"**السيرفر:** {ctx.guild.name}\n**المدة:** {duration} دقيقة\n**السبب:** {reason}\n**بواسطة:** {ctx.author.mention}"
            )
            await send_dm(user, dm_embed)
            
            embed = create_success_embed(
                "✅ تم الكتم",
                f"**العضو:** {user.mention}\n**المدة:** {duration} دقيقة\n**السبب:** {reason}\n**بواسطة:** {ctx.author.mention}"
            )
            await ctx.send(embed=embed)
            
        except discord.Forbidden:
            embed = create_error_embed(
                "❌ فشل الكتم",
                "ليس لدي الصلاحية لكتم هذا العضو."
            )
            await ctx.send(embed=embed)
        except Exception as e:
            embed = create_error_embed(
                "❌ خطأ",
                f"حدث خطأ أثناء الكتم: {str(e)}"
            )
            await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="unmute", description="فك كتم عضو")
    @app_commands.describe(user="العضو المراد فك كتمه")
    async def unmute(self, ctx, user: discord.Member):
        if not has_role_permission(ctx.author, ["admin", "kick_mod"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لفك كتم الأعضاء."
            )
            await ctx.send(embed=embed)
            return
        
        try:
            # Remove timeout
            await user.timeout(None)
            
            # Send DM
            dm_embed = create_success_embed(
                "🔊 تم فك كتمك",
                f"**السيرفر:** {ctx.guild.name}\n**بواسطة:** {ctx.author.mention}"
            )
            await send_dm(user, dm_embed)
            
            embed = create_success_embed(
                "✅ تم فك الكتم",
                f"**العضو:** {user.mention}\n**بواسطة:** {ctx.author.mention}"
            )
            await ctx.send(embed=embed)
            
        except Exception as e:
            embed = create_error_embed(
                "❌ خطأ",
                f"حدث خطأ أثناء فك الكتم: {str(e)}"
            )
            await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="warn", description="تحذير عضو")
    @app_commands.describe(user="العضو المراد تحذيره", reason="سبب التحذير")
    async def warn(self, ctx, user: discord.Member, *, reason: str):
        if not has_role_permission(ctx.author, ["admin", "kick_mod"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لتحذير الأعضاء."
            )
            await ctx.send(embed=embed)
            return
        
        # Add warning to database
        warning_id = db.add_warning(user.id, ctx.guild.id, ctx.author.id, reason)
        
        # Send DM
        dm_embed = create_warning_embed(
            "⚠️ تم تحذيرك",
            f"**السيرفر:** {ctx.guild.name}\n**السبب:** {reason}\n**بواسطة:** {ctx.author.mention}\n**رقم التحذير:** #{warning_id}"
        )
        await send_dm(user, dm_embed)
        
        embed = create_success_embed(
            "✅ تم التحذير",
            f"**العضو:** {user.mention}\n**السبب:** {reason}\n**رقم التحذير:** #{warning_id}\n**بواسطة:** {ctx.author.mention}"
        )
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="infractions", description="عرض تحذيرات عضو")
    @app_commands.describe(user="العضو المراد عرض تحذيراته")
    async def infractions(self, ctx, user: discord.Member):
        warnings = db.get_warnings(user.id, ctx.guild.id)
        
        embed = discord.Embed(
            title="⚠️ تحذيرات العضو",
            description=f"**العضو:** {user.mention}",
            color=COLORS["warning"]
        )
        
        if not warnings:
            embed.add_field(
                name="📋 النتيجة",
                value="لا توجد تحذيرات مسجلة",
                inline=False
            )
        else:
            for warning in warnings:
                moderator = ctx.guild.get_member(warning["moderator_id"])
                moderator_name = moderator.mention if moderator else "غير معروف"
                
                embed.add_field(
                    name=f"التحذير #{warning['id']}",
                    value=f"**السبب:** {warning['reason']}\n**بواسطة:** {moderator_name}\n**التاريخ:** {format_timestamp(warning['timestamp'])}",
                    inline=False
                )
        
        embed.set_footer(text=f"إجمالي التحذيرات: {len(warnings)}")
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="unwarn", description="حذف تحذير")
    @app_commands.describe(user="العضو", warning_id="رقم التحذير")
    async def unwarn(self, ctx, user: discord.Member, warning_id: int):
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لحذف التحذيرات."
            )
            await ctx.send(embed=embed)
            return
        
        success = db.remove_warning(user.id, ctx.guild.id, warning_id)
        
        if success:
            # Send DM
            dm_embed = create_success_embed(
                "✅ تم حذف تحذير",
                f"**السيرفر:** {ctx.guild.name}\n**رقم التحذير:** #{warning_id}\n**تم الحذف بواسطة:** {ctx.author.mention}"
            )
            await send_dm(user, dm_embed)
            
            embed = create_success_embed(
                "✅ تم حذف التحذير",
                f"**العضو:** {user.mention}\n**رقم التحذير:** #{warning_id}\n**بواسطة:** {ctx.author.mention}"
            )
            await ctx.send(embed=embed)
        else:
            embed = create_error_embed(
                "❌ تحذير غير موجود",
                "لم يتم العثور على التحذير المحدد."
            )
            await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="clear", description="مسح رسائل")
    @app_commands.describe(amount="عدد الرسائل")
    async def clear(self, ctx, amount: int):
        if not has_role_permission(ctx.author, ["admin", "kick_mod"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لمسح الرسائل."
            )
            await ctx.send(embed=embed)
            return
        
        if amount <= 0 or amount > 100:
            embed = create_error_embed(
                "❌ رقم خاطئ",
                "يجب أن يكون عدد الرسائل بين 1 و 100."
            )
            await ctx.send(embed=embed)
            return
        
        try:
            deleted = await ctx.channel.purge(limit=amount + 1)  # +1 for command message
            
            embed = create_success_embed(
                "✅ تم المسح",
                f"تم مسح {len(deleted) - 1} رسالة بواسطة {ctx.author.mention}"
            )
            msg = await ctx.send(embed=embed)
            
            # Delete confirmation message after 5 seconds
            await asyncio.sleep(5)
            await msg.delete()
            
        except discord.Forbidden:
            embed = create_error_embed(
                "❌ فشل المسح",
                "ليس لدي الصلاحية لمسح الرسائل."
            )
            await ctx.send(embed=embed)
        except Exception as e:
            embed = create_error_embed(
                "❌ خطأ",
                f"حدث خطأ أثناء المسح: {str(e)}"
            )
            await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="lock", description="قفل القناة")
    async def lock(self, ctx):
        if not has_role_permission(ctx.author, ["admin", "kick_mod"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لقفل القنوات."
            )
            await ctx.send(embed=embed)
            return
        
        try:
            overwrites = ctx.channel.overwrites_for(ctx.guild.default_role)
            overwrites.send_messages = False
            await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrites)
            
            embed = create_success_embed(
                "🔒 تم قفل القناة",
                f"تم قفل القناة بواسطة {ctx.author.mention}"
            )
            await ctx.send(embed=embed)
            
        except Exception as e:
            embed = create_error_embed(
                "❌ خطأ",
                f"حدث خطأ أثناء القفل: {str(e)}"
            )
            await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="unlock", description="فتح القناة")
    async def unlock(self, ctx):
        if not has_role_permission(ctx.author, ["admin", "kick_mod"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لفتح القنوات."
            )
            await ctx.send(embed=embed)
            return
        
        try:
            overwrites = ctx.channel.overwrites_for(ctx.guild.default_role)
            overwrites.send_messages = None
            await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrites)
            
            embed = create_success_embed(
                "🔓 تم فتح القناة",
                f"تم فتح القناة بواسطة {ctx.author.mention}"
            )
            await ctx.send(embed=embed)
            
        except Exception as e:
            embed = create_error_embed(
                "❌ خطأ",
                f"حدث خطأ أثناء الفتح: {str(e)}"
            )
            await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="say", description="إرسال رسالة")
    @app_commands.describe(message="الرسالة", embed="هل تريد إرسالها كـ embed؟", channel="القناة (اختياري)")
    async def say(self, ctx, message: str, embed: bool = False, channel: discord.TextChannel = None):
        if not has_role_permission(ctx.author, ["admin"]):
            embed_response = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لاستخدام هذا الأمر."
            )
            await ctx.send(embed=embed_response)
            return
        
        target_channel = channel or ctx.channel
        
        try:
            # Delete the command message if it's not a slash command
            if hasattr(ctx, 'message') and ctx.message:
                await ctx.message.delete()
            
            if embed:
                embed_msg = discord.Embed(
                    description=message,
                    color=COLORS["primary"]
                )
                await target_channel.send(embed=embed_msg)
            else:
                await target_channel.send(message)
            
            # Confirm if sent to different channel
            if channel and channel != ctx.channel:
                confirmation = create_success_embed(
                    "✅ تم الإرسال",
                    f"تم إرسال الرسالة إلى {channel.mention}"
                )
                await ctx.send(embed=confirmation, ephemeral=True)
                
        except Exception as e:
            embed_response = create_error_embed(
                "❌ خطأ",
                f"حدث خطأ أثناء الإرسال: {str(e)}"
            )
            await ctx.send(embed=embed_response)
    
    @commands.hybrid_command(name="rules", description="إدارة القوانين")
    @app_commands.describe(action="الإجراء", rule_type="نوع القانون", content="محتوى القانون")
    async def rules(self, ctx, action: str, rule_type: str = None, *, content: str = None):
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لإدارة القوانين."
            )
            await ctx.send(embed=embed)
            return
        
        valid_actions = ["set", "get", "list"]
        if action not in valid_actions:
            embed = create_error_embed(
                "❌ إجراء خاطئ",
                f"الإجراءات المتاحة: {', '.join(valid_actions)}"
            )
            await ctx.send(embed=embed)
            return
        
        if action == "set" and rule_type and content:
            db.set_rules(rule_type, content)
            embed = create_success_embed(
                "✅ تم تحديث القوانين",
                f"تم تحديث قوانين {rule_type}"
            )
            await ctx.send(embed=embed)
        elif action == "get" and rule_type:
            rules_content = db.get_rules(rule_type)
            embed = create_info_embed(
                f"📋 قوانين {rule_type}",
                rules_content
            )
            await ctx.send(embed=embed)
        elif action == "list":
            embed = create_info_embed(
                "📋 أنواع القوانين المتاحة",
                "support, store, admin, kick_mod, event"
            )
            await ctx.send(embed=embed)
        else:
            embed = create_error_embed(
                "❌ معاملات ناقصة",
                "استخدم: `/rules set نوع_القانون محتوى_القانون`"
            )
            await ctx.send(embed=embed)
    
    # Prefix command aliases
    @commands.command(name="timeout")
    async def timeout_alias(self, ctx, user: discord.Member, duration: int = 10, *, reason: str = "لم يتم تحديد سبب"):
        await self.mute(ctx, user, duration, reason=reason)
    
    @commands.command(name="untimeout")
    async def untimeout_alias(self, ctx, user: discord.Member):
        await self.unmute(ctx, user)
    
    @commands.command(name="warnings")
    async def warnings_alias(self, ctx, user: discord.Member):
        await self.infractions(ctx, user)
    
    # Command shortcuts
    @commands.command(name="b", hidden=True)
    async def ban_alias(self, ctx, user: discord.Member, *, reason: str = "لم يتم تحديد سبب"):
        await self.ban(ctx, user, reason=reason)
    
    @commands.command(name="k", hidden=True) 
    async def kick_alias(self, ctx, user: discord.Member, *, reason: str = "لم يتم تحديد سبب"):
        await self.kick(ctx, user, reason=reason)
    
    @commands.command(name="m", hidden=True)
    async def mute_alias(self, ctx, user: discord.Member, duration: int = 10, *, reason: str = "لم يتم تحديد سبب"):
        await self.mute(ctx, user, duration, reason=reason)
    
    @commands.command(name="um", hidden=True)
    async def unmute_alias(self, ctx, user: discord.Member):
        await self.unmute(ctx, user)
    
    @commands.command(name="w", hidden=True)
    async def warn_alias(self, ctx, user: discord.Member, *, reason: str = "لم يتم تحديد سبب"):
        await self.warn(ctx, user, reason=reason)
    
    @commands.command(name="inf", hidden=True)
    async def infractions_alias(self, ctx, user: discord.Member):
        await self.infractions(ctx, user)
    
    @commands.command(name="uw", hidden=True)
    async def unwarn_alias(self, ctx, user: discord.Member, warning_id: int):
        await self.unwarn(ctx, user, warning_id)
    
    @commands.command(name="c", hidden=True)
    async def clear_alias(self, ctx, amount: int = 10):
        await self.purge(ctx, amount)
    
    @commands.command(name="l", hidden=True)
    async def lock_alias(self, ctx):
        await self.lock(ctx)
    
    @commands.command(name="ul", hidden=True)
    async def unlock_alias(self, ctx):
        await self.unlock(ctx)
    
    @commands.command(name="s", hidden=True)
    async def say_alias(self, ctx, message: str, embed: bool = False, channel: discord.TextChannel = None):
        await self.say(ctx, message, embed, channel)

async def setup(bot):
    await bot.add_cog(Moderation(bot))
