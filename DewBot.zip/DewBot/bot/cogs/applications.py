import discord
from discord.ext import commands
from discord import app_commands
from bot.config import *
from bot.database_adapter import db
from bot.utils import *

class ApplicationModal(discord.ui.Modal):
    def __init__(self, app_type, questions):
        super().__init__(title=f'تقديم {app_type}')
        self.app_type = app_type
        
        # Add questions as text inputs (max 5 per modal)
        for i, question in enumerate(questions[:5]):
            text_input = discord.ui.TextInput(
                label=question,
                style=discord.TextStyle.paragraph,
                placeholder=f'أجب على: {question}',
                required=True,
                max_length=1000
            )
            self.add_item(text_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        # Collect answers
        answers = []
        for item in self.children:
            if isinstance(item, discord.ui.TextInput):
                answers.append(f"**{item.label}**\n{item.value}")
        
        # Create application embed
        embed = discord.Embed(
            title=f"📝 تقديم {self.app_type} جديد",
            description=f"**👤 المتقدم:** {interaction.user.mention}\n**📅 تاريخ التقديم:** <t:{int(discord.utils.utcnow().timestamp())}:F>\n**🆔 معرف المتقدم:** {interaction.user.id}",
            color=COLORS["primary"]
        )
        embed.set_thumbnail(url=interaction.user.display_avatar.url)
        
        # Add answers
        for i, answer in enumerate(answers):
            embed.add_field(
                name=f"السؤال {i+1}",
                value=answer,
                inline=False
            )
        
        # Create approval view
        view = ApplicationApprovalView(interaction.user.id, self.app_type)
        
        # Send to log channel based on app type
        app_type_mapping = {
            "إدارة": "staff",
            "مود": "mod", 
            "إيفنت": "event"
        }
        
        # Get log channel from database first, then fallback to config
        log_channel_id = db.get_application_log(interaction.guild.id, app_type_mapping.get(self.app_type)) or APPLICATION_LOGS.get(app_type_mapping.get(self.app_type))
        if log_channel_id:
            log_channel = interaction.guild.get_channel(log_channel_id)
            if log_channel:
                await log_channel.send(embed=embed, view=view)
        
        # Response to user
        success_embed = create_success_embed(
            "✅ تم إرسال التقديم",
            f"تم إرسال تقديمك لـ {self.app_type} بنجاح!\nسيتم مراجعته من قبل الإدارة قريباً."
        )
        await interaction.response.send_message(embed=success_embed, ephemeral=True)
        
        # Send DM confirmation
        dm_embed = create_info_embed(
            "📝 تأكيد التقديم",
            f"تم إرسال تقديمك لـ {self.app_type} بنجاح!\nسيتم إشعارك بالنتيجة قريباً."
        )
        await send_dm(interaction.user, dm_embed)

class ApplicationApprovalView(discord.ui.View):
    def __init__(self, user_id, app_type):
        super().__init__(timeout=None)
        self.user_id = user_id
        self.app_type = app_type
    
    @discord.ui.button(label='✅ قبول', style=discord.ButtonStyle.green, custom_id='approve_app')
    async def approve_application(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not has_role_permission(interaction.user, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية للتعامل مع التقديمات."
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        modal = ReasonModal("قبول", self.user_id, self.app_type)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label='❌ رفض', style=discord.ButtonStyle.red, custom_id='reject_app')
    async def reject_application(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not has_role_permission(interaction.user, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية للتعامل مع التقديمات."
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        modal = ReasonModal("رفض", self.user_id, self.app_type)
        await interaction.response.send_modal(modal)

class ReasonModal(discord.ui.Modal, title='سبب القرار'):
    def __init__(self, action, user_id, app_type):
        super().__init__()
        self.action = action
        self.user_id = user_id
        self.app_type = app_type
    
    reason = discord.ui.TextInput(
        label='السبب',
        style=discord.TextStyle.paragraph,
        placeholder='اكتب سبب القبول/الرفض...',
        required=True,
        max_length=1000
    )
    
    async def on_submit(self, interaction: discord.Interaction):
        user = interaction.guild.get_member(self.user_id)
        if not user:
            embed = create_error_embed(
                "❌ عضو غير موجود",
                "لم يتم العثور على العضو."
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Send DM to applicant
        if self.action == "قبول":
            dm_embed = create_success_embed(
                f"🎉 تم قبول تقديمك لـ {self.app_type}",
                f"**السبب:** {self.reason.value}\n\nمبروك! مرحباً بك في الفريق!"
            )
            color = COLORS["success"]
        else:
            dm_embed = create_error_embed(
                f"❌ تم رفض تقديمك لـ {self.app_type}",
                f"**السبب:** {self.reason.value}\n\nيمكنك التقديم مرة أخرى لاحقاً."
            )
            color = COLORS["error"]
        
        sent = await send_dm(user, dm_embed)
        
        # Update the original message
        result_embed = discord.Embed(
            title=f"تم {self.action} التقديم",
            description=f"**المتقدم:** {user.mention}\n**نوع التقديم:** {self.app_type}\n**تم {self.action} بواسطة:** {interaction.user.mention}\n**السبب:** {self.reason.value}",
            color=color
        )
        
        await interaction.response.edit_message(embed=result_embed, view=None)
        
        # Confirm action
        if sent:
            confirm_text = f"تم {self.action} التقديم وإشعار المتقدم."
        else:
            confirm_text = f"تم {self.action} التقديم (فشل إرسال الإشعار)."
        
        await interaction.followup.send(confirm_text, ephemeral=True)

class ApplicationPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label='👑 تقديم إدارة', style=discord.ButtonStyle.primary, custom_id='apply_staff')
    async def apply_staff(self, interaction: discord.Interaction, button: discord.ui.Button):
        questions = [
            "ما هو اسمك؟",
            "كم عمرك؟", 
            "ما هو جنسك؟",
            "ما هي خبراتك؟",
            "هل أنت إداري في سيرفرات أخرى؟"
        ]
        modal = ApplicationModal("إدارة", questions)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label='🛡️ تقديم مود', style=discord.ButtonStyle.primary, custom_id='apply_mod')
    async def apply_mod(self, interaction: discord.Interaction, button: discord.ui.Button):
        questions = [
            "ما هو اسمك؟",
            "كم عمرك؟",
            "ما هو جنسك؟", 
            "ما هي خبراتك؟",
            "هل أنت مود في سيرفرات أخرى؟ (اذكرها)"
        ]
        modal = ApplicationModal("مود", questions)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label='🎉 تقديم إيفنت', style=discord.ButtonStyle.primary, custom_id='apply_event')
    async def apply_event(self, interaction: discord.Interaction, button: discord.ui.Button):
        questions = [
            "ما هو اسمك؟",
            "كم عمرك؟",
            "ما هو جنسك؟",
            "ما هي خبراتك بالتفصيل؟", 
            "هل أنت ايفنت عند شخص آخر؟ (اذكره)"
        ]
        modal = ApplicationModal("إيفنت", questions)
        await interaction.response.send_modal(modal)

class Applications(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="apply-panel", description="إنشاء بانل التقديمات")
    async def apply_panel(self, ctx):
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لإنشاء بانل التقديمات."
            )
            await ctx.send(embed=embed)
            return
        
        embed = discord.Embed(
            title="📝 نظام التقديمات",
            description="اختر نوع التقديم الذي تريد تقديمه:",
            color=COLORS["primary"]
        )
        embed.add_field(
            name="👑 تقديم إدارة",
            value="للانضمام لفريق الإدارة",
            inline=True
        )
        embed.add_field(
            name="🛡️ تقديم مود",
            value="للانضمام لفريق المودريشن",
            inline=True
        )
        embed.add_field(
            name="🎉 تقديم إيفنت",
            value="للانضمام لفريق الفعاليات",
            inline=True
        )
        
        view = ApplicationPanelView()
        await ctx.send(embed=embed, view=view)
    
    @commands.hybrid_command(name="apply-staff", description="التقديم للإدارة")
    async def apply_staff(self, ctx):
        questions = [
            "ما هو اسمك؟",
            "كم عمرك؟",
            "ما هو جنسك؟",
            "ما هي خبراتك؟", 
            "هل أنت إداري في سيرفرات أخرى؟"
        ]
        modal = ApplicationModal("إدارة", questions)
        await ctx.interaction.response.send_modal(modal)
    
    @commands.hybrid_command(name="apply-mod", description="التقديم للمودريشن")
    async def apply_mod(self, ctx):
        questions = [
            "ما هو اسمك؟",
            "كم عمرك؟",
            "ما هو جنسك؟",
            "ما هي خبراتك؟",
            "هل أنت مود في سيرفرات أخرى؟ (اذكرها)"
        ]
        modal = ApplicationModal("مود", questions)
        await ctx.interaction.response.send_modal(modal)
    
    @commands.hybrid_command(name="apply-event", description="التقديم للفعاليات")
    async def apply_event(self, ctx):
        questions = [
            "ما هو اسمك؟",
            "كم عمرك؟",
            "ما هو جنسك؟",
            "ما هي خبراتك بالتفصيل؟",
            "هل أنت ايفنت عند شخص آخر؟ (اذكره)"
        ]
        modal = ApplicationModal("إيفنت", questions)
        await ctx.interaction.response.send_modal(modal)
    
    @commands.hybrid_command(name="set-application-log", description="تعيين قناة لوق التقديمات")
    @app_commands.describe(app_type="نوع التقديم", channel="القناة")
    async def set_application_log(self, ctx, app_type: str, channel: discord.TextChannel):
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لتعديل إعدادات التقديمات."
            )
            await ctx.send(embed=embed)
            return
        
        valid_types = ["staff", "mod", "event"]
        if app_type not in valid_types:
            embed = create_error_embed(
                "❌ نوع خاطئ",
                f"الأنواع المتاحة: {', '.join(valid_types)}"
            )
            await ctx.send(embed=embed)
            return
        
        # Save to database
        db.set_application_log(ctx.guild.id, app_type, channel.id)
        
        embed = create_success_embed(
            "✅ تم التحديث",
            f"تم تعيين {channel.mention} كقناة لوق لتقديمات {app_type}"
        )
        await ctx.send(embed=embed)

    # Command aliases (shortcuts)
    @commands.command(name="ap", hidden=True)
    async def apply_panel_alias(self, ctx):
        await self.apply_panel(ctx)
    
    @commands.command(name="as", hidden=True)
    async def apply_staff_alias(self, ctx):
        await self.apply_staff(ctx)
    
    @commands.command(name="am", hidden=True)
    async def apply_mod_alias(self, ctx):
        await self.apply_mod(ctx)
    
    @commands.command(name="ae", hidden=True)
    async def apply_event_alias(self, ctx):
        await self.apply_event(ctx)
    
    @commands.command(name="sal", hidden=True)
    async def set_application_log_alias(self, ctx, app_type: str, channel: discord.TextChannel):
        await self.set_application_log(ctx, app_type, channel)

async def setup(bot):
    await bot.add_cog(Applications(bot))
