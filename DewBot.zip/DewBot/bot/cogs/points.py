import discord
from discord.ext import commands
from discord import app_commands
from bot.config import *
from bot.database_adapter import db
from bot.utils import *

class Points(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="point", description="عرض نقاط عضو")
    @app_commands.describe(user="العضو المراد عرض نقاطه")
    async def point(self, ctx, user: discord.Member = None):
        if user is None:
            user = ctx.author
        
        points = db.get_points(user.id, ctx.guild.id)
        
        embed = discord.Embed(
            title="💎 نقاط العضو",
            description=f"**العضو:** {user.mention}\n**النقاط:** {points:,} نقطة",
            color=COLORS["info"]
        )
        embed.set_thumbnail(url=user.display_avatar.url)
        
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="points-add", description="إضافة نقاط لعضو")
    @app_commands.describe(user="العضو", points="عدد النقاط")
    async def points_add(self, ctx, user: discord.Member, points: int):
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لإدارة النقاط."
            )
            await ctx.send(embed=embed)
            return
        
        if points <= 0:
            embed = create_error_embed(
                "❌ رقم خاطئ",
                "يجب أن يكون عدد النقاط أكبر من 0."
            )
            await ctx.send(embed=embed)
            return
        
        old_points = db.get_points(user.id, ctx.guild.id)
        db.add_points(user.id, points, ctx.guild.id)
        new_points = db.get_points(user.id, ctx.guild.id)
        
        embed = create_success_embed(
            "✅ تم إضافة النقاط",
            f"**العضو:** {user.mention}\n**النقاط المضافة:** {points:,}\n**النقاط السابقة:** {old_points:,}\n**النقاط الحالية:** {new_points:,}"
        )
        await ctx.send(embed=embed)
        
        # Send DM to user
        dm_embed = create_success_embed(
            "🎉 تم إضافة نقاط",
            f"تم إضافة {points:,} نقطة إلى حسابك!\nرصيدك الحالي: {new_points:,} نقطة"
        )
        await send_dm(user, dm_embed)
    
    @commands.hybrid_command(name="points-remove", description="إزالة نقاط من عضو")
    @app_commands.describe(user="العضو", points="عدد النقاط")
    async def points_remove(self, ctx, user: discord.Member, points: int):
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لإدارة النقاط."
            )
            await ctx.send(embed=embed)
            return
        
        if points <= 0:
            embed = create_error_embed(
                "❌ رقم خاطئ",
                "يجب أن يكون عدد النقاط أكبر من 0."
            )
            await ctx.send(embed=embed)
            return
        
        old_points = db.get_points(user.id, ctx.guild.id)
        db.remove_points(user.id, points, ctx.guild.id)
        new_points = db.get_points(user.id, ctx.guild.id)
        
        embed = create_success_embed(
            "✅ تم خصم النقاط",
            f"**العضو:** {user.mention}\n**النقاط المخصومة:** {points:,}\n**النقاط السابقة:** {old_points:,}\n**النقاط الحالية:** {new_points:,}"
        )
        await ctx.send(embed=embed)
        
        # Send DM to user
        dm_embed = create_warning_embed(
            "📉 تم خصم نقاط",
            f"تم خصم {points:,} نقطة من حسابك.\nرصيدك الحالي: {new_points:,} نقطة"
        )
        await send_dm(user, dm_embed)
    
    @commands.hybrid_command(name="points-set", description="تعيين نقاط عضو")
    @app_commands.describe(user="العضو", points="عدد النقاط")
    async def points_set(self, ctx, user: discord.Member, points: int):
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لإدارة النقاط."
            )
            await ctx.send(embed=embed)
            return
        
        if points < 0:
            embed = create_error_embed(
                "❌ رقم خاطئ",
                "لا يمكن أن تكون النقاط أقل من 0."
            )
            await ctx.send(embed=embed)
            return
        
        old_points = db.get_points(user.id, ctx.guild.id)
        db.set_points(user.id, points, ctx.guild.id)
        
        embed = create_success_embed(
            "✅ تم تعيين النقاط",
            f"**العضو:** {user.mention}\n**النقاط السابقة:** {old_points:,}\n**النقاط الجديدة:** {points:,}"
        )
        await ctx.send(embed=embed)
        
        # Send DM to user
        dm_embed = create_info_embed(
            "📊 تم تحديث النقاط",
            f"تم تعيين نقاطك إلى {points:,} نقطة."
        )
        await send_dm(user, dm_embed)
    
    @commands.hybrid_command(name="points-delete", description="حذف نقاط عضو")
    @app_commands.describe(user="العضو")
    async def points_delete(self, ctx, user: discord.Member):
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لإدارة النقاط."
            )
            await ctx.send(embed=embed)
            return
        
        old_points = db.get_points(user.id, ctx.guild.id)
        db.delete_points(user.id, ctx.guild.id)
        
        embed = create_success_embed(
            "✅ تم حذف النقاط",
            f"**العضو:** {user.mention}\n**النقاط المحذوفة:** {old_points:,}"
        )
        await ctx.send(embed=embed)
        
        # Send DM to user
        dm_embed = create_warning_embed(
            "🗑️ تم حذف النقاط",
            "تم حذف جميع نقاطك من النظام."
        )
        await send_dm(user, dm_embed)
    
    @commands.hybrid_command(name="points-list", description="عرض قائمة النقاط")
    async def points_list(self, ctx):
        leaderboard = db.get_leaderboard(ctx.guild.id, limit=50)
        
        if not leaderboard:
            embed = create_info_embed(
                "📋 قائمة النقاط",
                "لا توجد نقاط مسجلة حتى الآن."
            )
            await ctx.send(embed=embed)
            return
        
        # Sort by points (highest first)
        sorted_points = sorted(all_points.items(), key=lambda x: x[1], reverse=True)
        
        embed = discord.Embed(
            title="📋 قائمة النقاط",
            color=COLORS["info"]
        )
        
        description = ""
        for i, (user_id, points) in enumerate(sorted_points[:10], 1):
            user = ctx.guild.get_member(int(user_id))
            if user:
                description += f"{i}. {user.mention} - {points:,} نقطة\n"
            else:
                description += f"{i}. مستخدم غير معروف - {points:,} نقطة\n"
        
        embed.description = description or "لا توجد بيانات."
        
        if len(sorted_points) > 10:
            embed.set_footer(text=f"عرض أفضل 10 من أصل {len(sorted_points)} عضو")
        
        await ctx.send(embed=embed)
    
    # Prefix command equivalents
    @commands.command(name="n")
    async def n_command(self, ctx, user: discord.Member = None, action: str = None):
        """النقاط - استخدام: !n @user +5 أو !n @user -3 أو !n @user 10"""
        if user is None:
            # Show own points
            await self.point(ctx)
            return
        
        if action is None:
            # Show user points
            await self.point(ctx, user)
            return
        
        if not has_role_permission(ctx.author, ["admin"]):
            embed = create_error_embed(
                "🚫 ليس لديك صلاحية",
                "ليس لديك الصلاحية لإدارة النقاط."
            )
            await ctx.send(embed=embed)
            return
        
        try:
            if action.startswith('+'):
                points = int(action[1:])
                await self.points_add(ctx, user, points)
            elif action.startswith('-'):
                points = int(action[1:])
                await self.points_remove(ctx, user, points)
            else:
                points = int(action)
                await self.points_set(ctx, user, points)
        except ValueError:
            embed = create_error_embed(
                "❌ تنسيق خاطئ",
                "استخدم: `!n @user +5` أو `!n @user -3` أو `!n @user 10`"
            )
            await ctx.send(embed=embed)
    
    @commands.command(name="re")
    async def re_command(self, ctx, user: discord.Member):
        """حذف نقاط - استخدام: !re @user"""
        await self.points_delete(ctx, user)

    # Command shortcuts
    @commands.command(name="p", hidden=True)
    async def point_alias(self, ctx, user: discord.Member):
        await self.point(ctx, user)
    
    @commands.command(name="pl", hidden=True)
    async def points_list_alias(self, ctx):
        await self.points_list(ctx)

async def setup(bot):
    await bot.add_cog(Points(bot))
