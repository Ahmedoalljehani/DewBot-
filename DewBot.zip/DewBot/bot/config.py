import os

# Bot Configuration
BOT_TOKEN = os.getenv("DISCORD_TOKEN", "MTM5NTc5MTI3NzIxOTM4NTQzNQ.GEQU30.4A2F4MYViBWLxL97Hdl0yNcq76hxUIZwIhq56s")
APPLICATION_ID = "1395791277219385435"
PUBLIC_KEY = "81f3e4f194651afd22497b88ff1383a0c726ef5dd3d6d60d645469e0205cc7e6"
CLIENT_ID = "1395791277219385435"
CLIENT_SECRET = "Z3xulq_D-YoEoSNzh65hPj302PTO_2io"

# Role IDs
ROLES = {
    "staff": 1391504828072726741,
    "admin": 1391504798452416614, 
    "store_team": 1391504766277914816,
    "kick_mod": 1391545626071928853
}

# Ticket Category IDs
TICKET_CATEGORIES = {
    "support": 1391503700832419981,
    "store": 1391503794239438918,
    "admin": 1391503960883462204,
    "kick_mod": 1394818359039754363,
    "event": 1394818497275494458
}

# Application Log Channels
APPLICATION_LOGS = {
    "staff": 1391908074666590218,
    "mod": 1391916860315930784,
    "event": 1391917882476069056
}

# Ticket Log Channels
TICKET_LOGS = {
    "support": 1391504322390659184,
    "store": 1391504330577674321,
    "admin": 1391504340673626338,
    "kick_mod": 1394816975338864721,
    "event": 1394819192900944032
}

# Colors for embeds
COLORS = {
    "success": 0x00ff00,
    "error": 0xff0000,
    "warning": 0xffaa00,
    "info": 0x0099ff,
    "primary": 0x5865F2
}

# Ticket role mentions
TICKET_ROLE_MENTIONS = {
    "support": f"<@&{ROLES['staff']}>",
    "store": f"<@&{ROLES['store_team']}>",
    "admin": f"<@&{ROLES['admin']}>",
    "kick_mod": f"<@&{ROLES['kick_mod']}>",
    "event": f"<@&{ROLES['staff']}>"
}

# Default rules text
DEFAULT_RULES = {
    "support": "📋 **قوانين التذاكر**\n\n1. كن مهذباً ومحترماً\n2. اشرح مشكلتك بوضوح\n3. لا تكرر الرسائل\n4. انتظر الرد من الفريق\n5. لا تفتح أكثر من تذكرة واحدة",
    "store": "🛒 **قوانين المتجر**\n\n1. تأكد من المنتج قبل الشراء\n2. لا يمكن إرجاع المنتجات الرقمية\n3. الدفع آمن 100%\n4. خدمة العملاء متاحة 24/7",
    "admin": "👑 **قوانين الإدارة**\n\n1. هذه تذكرة إدارية خاصة\n2. تعامل بجدية مع الموضوع\n3. لا تشارك معلومات سرية\n4. احترم خصوصية الآخرين",
    "kick_mod": "🛡️ **قوانين المود**\n\n1. أبلغ عن المخالفات بوضوح\n2. أرفق الأدلة إن وجدت\n3. لا تتخذ إجراءات بنفسك\n4. دع الفريق يتولى الأمر",
    "event": "🎉 **قوانين الفعاليات**\n\n1. اقترح أفكار إبداعية\n2. حدد التاريخ والوقت\n3. اشرح تفاصيل الفعالية\n4. تأكد من توفر الجوائز"
}
