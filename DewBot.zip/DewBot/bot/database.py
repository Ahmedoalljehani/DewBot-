import json
import os
from datetime import datetime

class Database:
    def __init__(self):
        self.data_file = "bot_data.json"
        self.data = self.load_data()
    
    def load_data(self):
        if os.path.exists(self.data_file):
            with open(self.data_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {
            "points": {},
            "warnings": {},
            "tickets": {},
            "applications": {},
            "rules": {},
            "ticket_counter": 0
        }
    
    def save_data(self):
        with open(self.data_file, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
    
    # Points system
    def get_points(self, user_id):
        return self.data["points"].get(str(user_id), 0)
    
    def set_points(self, user_id, points):
        self.data["points"][str(user_id)] = points
        self.save_data()
    
    def add_points(self, user_id, points):
        current = self.get_points(user_id)
        self.set_points(user_id, current + points)
    
    def remove_points(self, user_id, points):
        current = self.get_points(user_id)
        self.set_points(user_id, max(0, current - points))
    
    def delete_points(self, user_id):
        if str(user_id) in self.data["points"]:
            del self.data["points"][str(user_id)]
            self.save_data()
    
    def get_all_points(self):
        return self.data["points"]
    
    # Warnings system
    def add_warning(self, user_id, guild_id, moderator_id, reason):
        user_key = f"{guild_id}_{user_id}"
        if user_key not in self.data["warnings"]:
            self.data["warnings"][user_key] = []
        
        warning = {
            "id": len(self.data["warnings"][user_key]) + 1,
            "moderator_id": moderator_id,
            "reason": reason,
            "timestamp": datetime.now().isoformat()
        }
        
        self.data["warnings"][user_key].append(warning)
        self.save_data()
        return warning["id"]
    
    def get_warnings(self, user_id, guild_id):
        user_key = f"{guild_id}_{user_id}"
        return self.data["warnings"].get(user_key, [])
    
    def remove_warning(self, user_id, guild_id, warning_id):
        user_key = f"{guild_id}_{user_id}"
        if user_key in self.data["warnings"]:
            self.data["warnings"][user_key] = [
                w for w in self.data["warnings"][user_key] 
                if w["id"] != warning_id
            ]
            self.save_data()
            return True
        return False
    
    # Tickets system
    def create_ticket(self, user_id, guild_id, ticket_type, channel_id):
        self.data["ticket_counter"] += 1
        ticket_id = self.data["ticket_counter"]
        
        ticket = {
            "id": ticket_id,
            "user_id": user_id,
            "guild_id": guild_id,
            "type": ticket_type,
            "channel_id": channel_id,
            "created_at": datetime.now().isoformat(),
            "claimed_by": None,
            "status": "open"
        }
        
        self.data["tickets"][str(ticket_id)] = ticket
        self.save_data()
        return ticket_id
    
    def get_ticket(self, ticket_id):
        return self.data["tickets"].get(str(ticket_id))
    
    def close_ticket(self, ticket_id):
        if str(ticket_id) in self.data["tickets"]:
            self.data["tickets"][str(ticket_id)]["status"] = "closed"
            self.save_data()
    
    def claim_ticket(self, ticket_id, moderator_id):
        if str(ticket_id) in self.data["tickets"]:
            self.data["tickets"][str(ticket_id)]["claimed_by"] = moderator_id
            self.save_data()
    
    def unclaim_ticket(self, ticket_id):
        if str(ticket_id) in self.data["tickets"]:
            self.data["tickets"][str(ticket_id)]["claimed_by"] = None
            self.save_data()
    
    # Rules system
    def set_rules(self, ticket_type, rules_text):
        self.data["rules"][ticket_type] = rules_text
        self.save_data()
    
    def get_rules(self, ticket_type):
        from bot.config import DEFAULT_RULES
        return self.data["rules"].get(ticket_type, DEFAULT_RULES.get(ticket_type, ""))
    
    # Ticket logs configuration
    def set_ticket_log(self, ticket_type, channel_id):
        if "ticket_logs" not in self.data:
            self.data["ticket_logs"] = {}
        self.data["ticket_logs"][ticket_type] = channel_id
        self.save_data()
    
    def get_ticket_log(self, ticket_type):
        return self.data.get("ticket_logs", {}).get(ticket_type)
    
    # Application logs configuration  
    def set_application_log(self, app_type, channel_id):
        if "application_logs" not in self.data:
            self.data["application_logs"] = {}
        self.data["application_logs"][app_type] = channel_id
        self.save_data()
    
    def get_application_log(self, app_type):
        return self.data.get("application_logs", {}).get(app_type)
    
    # Supervisor roles configuration
    def set_supervisor_role(self, ticket_type, role_id):
        if "supervisor_roles" not in self.data:
            self.data["supervisor_roles"] = {}
        self.data["supervisor_roles"][ticket_type] = role_id
        self.save_data()
    
    def get_supervisor_role(self, ticket_type):
        return self.data.get("supervisor_roles", {}).get(ticket_type)

# Global database instance
db = Database()
