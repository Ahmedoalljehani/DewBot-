from sqlalchemy.orm import Session
from sqlalchemy import and_, desc
from bot.models import *
from datetime import datetime, timedelta
import json
import asyncio
import threading

class DatabaseManager:
    def __init__(self):
        self.session = None
        self._lock = threading.Lock()
    
    def get_session(self):
        """Get or create database session"""
        if not self.session:
            self.session = SessionLocal()
        return self.session
    
    def close_session(self):
        """Close database session"""
        if self.session:
            self.session.close()
            self.session = None
    
    def commit(self):
        """Commit changes to database"""
        try:
            session = self.get_session()
            session.commit()
        except Exception as e:
            session.rollback()
            raise e
    
    # User management
    def get_or_create_user(self, user_id: int, guild_id: int, username: str = None):
        """Get existing user or create new one"""
        session = self.get_session()
        user = session.query(User).filter(
            and_(User.id == user_id, User.guild_id == guild_id)
        ).first()
        
        if not user:
            user = User(id=user_id, guild_id=guild_id, username=username)
            session.add(user)
            self.commit()
        elif username and user.username != username:
            user.username = username
            user.updated_at = datetime.utcnow()
            self.commit()
            
        return user
    
    def update_user_points(self, user_id: int, guild_id: int, points: int):
        """Update user points"""
        user = self.get_or_create_user(user_id, guild_id)
        user.points = points
        user.updated_at = datetime.utcnow()
        self.commit()
    
    def get_user_points(self, user_id: int, guild_id: int):
        """Get user points"""
        user = self.get_or_create_user(user_id, guild_id)
        return user.points
    
    def get_leaderboard(self, guild_id: int, limit: int = 10):
        """Get points leaderboard"""
        session = self.get_session()
        users = session.query(User).filter(
            and_(User.guild_id == guild_id, User.points > 0)
        ).order_by(desc(User.points)).limit(limit).all()
        return users
    
    # Warning system
    def add_warning(self, user_id: int, guild_id: int, moderator_id: int, reason: str):
        """Add warning to user"""
        session = self.get_session()
        warning = Warning(
            user_id=user_id,
            guild_id=guild_id,
            moderator_id=moderator_id,
            reason=reason
        )
        session.add(warning)
        
        # Update user warning count
        user = self.get_or_create_user(user_id, guild_id)
        user.warnings_count += 1
        user.updated_at = datetime.utcnow()
        
        self.commit()
        return warning.id
    
    def get_warnings(self, user_id: int, guild_id: int):
        """Get user warnings"""
        session = self.get_session()
        warnings = session.query(Warning).filter(
            and_(Warning.user_id == user_id, Warning.guild_id == guild_id)
        ).order_by(desc(Warning.created_at)).all()
        return warnings
    
    def remove_warning(self, user_id: int, guild_id: int, warning_id: int):
        """Remove warning"""
        session = self.get_session()
        warning = session.query(Warning).filter(
            and_(
                Warning.id == warning_id,
                Warning.user_id == user_id,
                Warning.guild_id == guild_id
            )
        ).first()
        
        if warning:
            session.delete(warning)
            
            # Update user warning count
            user = self.get_or_create_user(user_id, guild_id)
            user.warnings_count = max(0, user.warnings_count - 1)
            user.updated_at = datetime.utcnow()
            
            self.commit()
            return True
        return False
    
    # Ticket system
    def create_ticket(self, user_id: int, guild_id: int, channel_id: int, ticket_type: str):
        """Create new ticket"""
        session = self.get_session()
        ticket = Ticket(
            user_id=user_id,
            guild_id=guild_id,
            channel_id=channel_id,
            ticket_type=ticket_type
        )
        session.add(ticket)
        self.commit()
        return ticket.id
    
    def get_ticket(self, ticket_id: int):
        """Get ticket by ID"""
        session = self.get_session()
        return session.query(Ticket).filter(Ticket.id == ticket_id).first()
    
    def get_ticket_by_channel(self, channel_id: int):
        """Get ticket by channel ID"""
        session = self.get_session()
        return session.query(Ticket).filter(Ticket.channel_id == channel_id).first()
    
    def close_ticket(self, ticket_id: int, conversation_log: str = None):
        """Close ticket"""
        session = self.get_session()
        ticket = session.query(Ticket).filter(Ticket.id == ticket_id).first()
        if ticket:
            ticket.status = 'closed'
            ticket.closed_at = datetime.utcnow()
            if conversation_log:
                ticket.conversation_log = conversation_log
            self.commit()
    
    def claim_ticket(self, ticket_id: int, moderator_id: int):
        """Claim ticket"""
        session = self.get_session()
        ticket = session.query(Ticket).filter(Ticket.id == ticket_id).first()
        if ticket:
            ticket.claimed_by = moderator_id
            self.commit()
    
    def unclaim_ticket(self, ticket_id: int):
        """Unclaim ticket"""
        session = self.get_session()
        ticket = session.query(Ticket).filter(Ticket.id == ticket_id).first()
        if ticket:
            ticket.claimed_by = None
            self.commit()
    
    # Application system
    def create_application(self, user_id: int, guild_id: int, app_type: str, answers: list):
        """Create new application"""
        session = self.get_session()
        application = Application(
            user_id=user_id,
            guild_id=guild_id,
            app_type=app_type,
            answers=json.dumps(answers)
        )
        session.add(application)
        self.commit()
        return application.id
    
    def update_application_status(self, app_id: int, status: str, reviewer_id: int, reason: str = None):
        """Update application status"""
        session = self.get_session()
        application = session.query(Application).filter(Application.id == app_id).first()
        if application:
            application.status = status
            application.reviewed_by = reviewer_id
            application.review_reason = reason
            application.reviewed_at = datetime.utcnow()
            self.commit()
            return True
        return False
    
    def get_application(self, app_id: int):
        """Get application by ID"""
        session = self.get_session()
        return session.query(Application).filter(Application.id == app_id).first()
    
    # Configuration system
    def set_config(self, guild_id: int, key: str, value: str):
        """Set configuration value"""
        session = self.get_session()
        config = session.query(BotConfig).filter(
            and_(BotConfig.guild_id == guild_id, BotConfig.key == key)
        ).first()
        
        if config:
            config.value = value
            config.updated_at = datetime.utcnow()
        else:
            config = BotConfig(guild_id=guild_id, key=key, value=value)
            session.add(config)
        
        self.commit()
    
    def get_config(self, guild_id: int, key: str, default=None):
        """Get configuration value"""
        session = self.get_session()
        config = session.query(BotConfig).filter(
            and_(BotConfig.guild_id == guild_id, BotConfig.key == key)
        ).first()
        
        return config.value if config else default
    
    def get_all_configs(self, guild_id: int):
        """Get all configurations for guild"""
        session = self.get_session()
        configs = session.query(BotConfig).filter(BotConfig.guild_id == guild_id).all()
        return {config.key: config.value for config in configs}
    
    # Moderation logs
    def add_mod_log(self, guild_id: int, user_id: int, moderator_id: int, action: str, reason: str, duration: int = None):
        """Add moderation log"""
        session = self.get_session()
        mod_log = ModLog(
            guild_id=guild_id,
            user_id=user_id,
            moderator_id=moderator_id,
            action=action,
            reason=reason,
            duration=duration
        )
        session.add(mod_log)
        self.commit()
        return mod_log.id
    
    def get_mod_logs(self, guild_id: int, user_id: int = None, limit: int = 50):
        """Get moderation logs"""
        session = self.get_session()
        query = session.query(ModLog).filter(ModLog.guild_id == guild_id)
        
        if user_id:
            query = query.filter(ModLog.user_id == user_id)
        
        logs = query.order_by(desc(ModLog.created_at)).limit(limit).all()
        return logs
    
    # Helper methods for ticket/application logs
    def set_ticket_log(self, guild_id: int, ticket_type: str, channel_id: int):
        """Set ticket log channel"""
        self.set_config(guild_id, f"ticket_log_{ticket_type}", str(channel_id))
    
    def get_ticket_log(self, guild_id: int, ticket_type: str):
        """Get ticket log channel"""
        value = self.get_config(guild_id, f"ticket_log_{ticket_type}")
        return int(value) if value else None
    
    def set_application_log(self, guild_id: int, app_type: str, channel_id: int):
        """Set application log channel"""
        self.set_config(guild_id, f"application_log_{app_type}", str(channel_id))
    
    def get_application_log(self, guild_id: int, app_type: str):
        """Get application log channel"""
        value = self.get_config(guild_id, f"application_log_{app_type}")
        return int(value) if value else None
    
    def set_supervisor_role(self, guild_id: int, ticket_type: str, role_id: int):
        """Set supervisor role for ticket type"""
        self.set_config(guild_id, f"supervisor_{ticket_type}", str(role_id))
    
    def get_supervisor_role(self, guild_id: int, ticket_type: str):
        """Get supervisor role for ticket type"""
        value = self.get_config(guild_id, f"supervisor_{ticket_type}")
        return int(value) if value else None

# Global database instance
db_manager = DatabaseManager()