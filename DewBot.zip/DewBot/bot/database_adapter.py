"""
Database adapter to maintain compatibility between old JSON system and new PostgreSQL system
This allows gradual migration without breaking existing functionality
"""

from bot.database_new import db_manager
from bot.models import get_db
import json

class DatabaseAdapter:
    def __init__(self):
        self.db_manager = db_manager
        self.guild_id = None  # Will be set per operation
    
    def set_guild_id(self, guild_id):
        """Set the current guild ID for operations"""
        self.guild_id = guild_id
    
    # Points system compatibility
    def get_points(self, user_id, guild_id=None):
        """Get user points - compatibility method"""
        if guild_id is None:
            guild_id = self.guild_id
        return self.db_manager.get_user_points(user_id, guild_id)
    
    def add_points(self, user_id, points, guild_id=None):
        """Add points to user - compatibility method"""
        if guild_id is None:
            guild_id = self.guild_id 
        current_points = self.get_points(user_id, guild_id)
        new_points = current_points + points
        self.db_manager.update_user_points(user_id, guild_id, new_points)
    
    def remove_points(self, user_id, points, guild_id=None):
        """Remove points from user"""
        if guild_id is None:
            guild_id = self.guild_id
        current_points = self.get_points(user_id, guild_id)
        new_points = max(0, current_points - points)
        self.db_manager.update_user_points(user_id, guild_id, new_points)
    
    def set_points(self, user_id, points, guild_id=None):
        """Set user points to specific value"""
        if guild_id is None:
            guild_id = self.guild_id
        self.db_manager.update_user_points(user_id, guild_id, points)
    
    def delete_points(self, user_id, guild_id=None):
        """Delete user points (set to 0)"""
        if guild_id is None:
            guild_id = self.guild_id
        self.db_manager.update_user_points(user_id, guild_id, 0)
    
    def get_leaderboard(self, guild_id=None, limit=10):
        """Get points leaderboard"""
        if guild_id is None:
            guild_id = self.guild_id
        return self.db_manager.get_leaderboard(guild_id, limit)
    
    # Warning system compatibility
    def add_warning(self, user_id, guild_id, moderator_id, reason):
        """Add warning to user"""
        return self.db_manager.add_warning(user_id, guild_id, moderator_id, reason)
    
    def get_warnings(self, user_id, guild_id):
        """Get user warnings"""
        return self.db_manager.get_warnings(user_id, guild_id)
    
    def remove_warning(self, user_id, guild_id, warning_id):
        """Remove warning"""
        return self.db_manager.remove_warning(user_id, guild_id, warning_id)
    
    # Ticket system compatibility
    def create_ticket(self, user_id, guild_id, ticket_type, channel_id):
        """Create new ticket"""
        return self.db_manager.create_ticket(user_id, guild_id, channel_id, ticket_type)
    
    def get_ticket(self, ticket_id):
        """Get ticket by ID"""
        return self.db_manager.get_ticket(ticket_id)
    
    def get_ticket_by_channel(self, channel_id):
        """Get ticket by channel ID"""
        return self.db_manager.get_ticket_by_channel(channel_id)
    
    def close_ticket(self, ticket_id, conversation_log=None):
        """Close ticket"""
        self.db_manager.close_ticket(ticket_id, conversation_log)
    
    def claim_ticket(self, ticket_id, moderator_id):
        """Claim ticket"""
        self.db_manager.claim_ticket(ticket_id, moderator_id)
    
    def unclaim_ticket(self, ticket_id):
        """Unclaim ticket"""
        self.db_manager.unclaim_ticket(ticket_id)
    
    # Configuration system
    def set_ticket_log(self, guild_id, ticket_type, channel_id):
        """Set ticket log channel"""  
        self.db_manager.set_ticket_log(guild_id, ticket_type, channel_id)
    
    def get_ticket_log(self, guild_id, ticket_type):
        """Get ticket log channel"""
        return self.db_manager.get_ticket_log(guild_id, ticket_type)
    
    def set_application_log(self, guild_id, app_type, channel_id):
        """Set application log channel"""
        self.db_manager.set_application_log(guild_id, app_type, channel_id)
    
    def get_application_log(self, guild_id, app_type):
        """Get application log channel"""
        return self.db_manager.get_application_log(guild_id, app_type)
    
    def set_supervisor_role(self, guild_id, ticket_type, role_id):
        """Set supervisor role for ticket type"""
        self.db_manager.set_supervisor_role(guild_id, ticket_type, role_id)
    
    def get_supervisor_role(self, guild_id, ticket_type):
        """Get supervisor role for ticket type"""
        return self.db_manager.get_supervisor_role(guild_id, ticket_type)
    
    def set_rules(self, guild_id, ticket_type, rules_text):
        """Set rules for ticket type"""
        self.db_manager.set_config(guild_id, f"rules_{ticket_type}", rules_text)
    
    def get_rules(self, guild_id, ticket_type):
        """Get rules for ticket type"""
        return self.db_manager.get_config(guild_id, f"rules_{ticket_type}", "لا توجد قوانين محددة.")
    
    # Application system
    def create_application(self, user_id, guild_id, app_type, answers):
        """Create new application"""
        return self.db_manager.create_application(user_id, guild_id, app_type, answers)
    
    def get_application(self, app_id):
        """Get application by ID"""
        return self.db_manager.get_application(app_id)
    
    def update_application_status(self, app_id, status, reviewer_id, reason=None):
        """Update application status"""
        return self.db_manager.update_application_status(app_id, status, reviewer_id, reason)
    
    # Moderation logs
    def add_mod_log(self, guild_id, user_id, moderator_id, action, reason, duration=None):
        """Add moderation log"""
        return self.db_manager.add_mod_log(guild_id, user_id, moderator_id, action, reason, duration)
    
    def get_mod_logs(self, guild_id, user_id=None, limit=50):
        """Get moderation logs"""
        return self.db_manager.get_mod_logs(guild_id, user_id, limit)
    
    # Compatibility properties and methods for old system
    @property
    def data(self):
        """Simulate old data structure for compatibility"""
        return {
            "tickets": {},
            "points": {},
            "warnings": {},
            "applications": {},
            "config": {}
        }
    
    def save_data(self):
        """Compatibility method - does nothing as we auto-commit"""
        pass

# Global database adapter instance
db = DatabaseAdapter()