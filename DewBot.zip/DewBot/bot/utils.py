import discord
from discord.ext import commands
from bot.config import ROLES, COLORS

def has_role_permission(member, required_roles):
    """Check if member has any of the required roles"""
    if not member or not member.roles:
        return False
    
    member_role_ids = [role.id for role in member.roles]
    
    for role_name in required_roles:
        if ROLES.get(role_name) in member_role_ids:
            return True
    return False

def can_use_bot(member):
    """Check if member can use bot commands (staff only)"""
    if not member or not member.roles:
        return False
    
    # Allow bot usage only for staff roles
    staff_roles = ["admin", "staff", "store_team", "kick_mod"]
    return has_role_permission(member, staff_roles)

async def get_channel_history(channel, limit=100):
    """Get channel message history for ticket logs"""
    messages = []
    try:
        async for message in channel.history(limit=limit, oldest_first=True):
            if not message.author.bot or message.embeds or message.attachments:
                timestamp = f"<t:{int(message.created_at.timestamp())}:f>"
                content = message.content or "[Embed/Attachment]"
                messages.append(f"**{message.author.display_name}** ({timestamp}):\n{content}\n")
        return "\n".join(messages)
    except:
        return "لا يمكن استرداد سجل المحادثة"

def create_error_embed(title, description):
    """Create a standardized error embed"""
    embed = discord.Embed(
        title=title,
        description=description,
        color=COLORS["error"]
    )
    return embed

def create_success_embed(title, description):
    """Create a standardized success embed"""
    embed = discord.Embed(
        title=title,
        description=description,
        color=COLORS["success"]
    )
    return embed

def create_info_embed(title, description):
    """Create a standardized info embed"""
    embed = discord.Embed(
        title=title,
        description=description,
        color=COLORS["info"]
    )
    return embed

def create_warning_embed(title, description):
    """Create a standardized warning embed"""
    embed = discord.Embed(
        title=title,
        description=description,
        color=COLORS["warning"]
    )
    return embed

async def send_dm(user, embed):
    """Send DM to user with error handling"""
    try:
        await user.send(embed=embed)
        return True
    except discord.Forbidden:
        return False
    except discord.HTTPException:
        return False

def format_timestamp(dt_string):
    """Format datetime string to Discord timestamp"""
    from datetime import datetime
    dt = datetime.fromisoformat(dt_string)
    return f"<t:{int(dt.timestamp())}:F>"

def requires_roles(*role_names):
    """Decorator to check if user has required roles"""
    def decorator(func):
        async def wrapper(self, ctx, *args, **kwargs):
            if not has_role_permission(ctx.author, role_names):
                embed = create_error_embed(
                    "🚫 ليس لديك صلاحية",
                    "ليس لديك الصلاحية المطلوبة لتنفيذ هذا الأمر."
                )
                await ctx.send(embed=embed)
                return
            return await func(self, ctx, *args, **kwargs)
        return wrapper
    return decorator

class ConfirmView(discord.ui.View):
    def __init__(self, *, timeout=60):
        super().__init__(timeout=timeout)
        self.value = None
    
    @discord.ui.button(label='تأكيد', style=discord.ButtonStyle.green)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.value = True
        self.stop()
        await interaction.response.defer()
    
    @discord.ui.button(label='إلغاء', style=discord.ButtonStyle.red)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.value = False
        self.stop()
        await interaction.response.defer()
